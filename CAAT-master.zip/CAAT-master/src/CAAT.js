/**
 * See LICENSE file.
 *
 * Library namespace.
 * CAAT stands for: Canvas Advanced Animation Tookit.
 */


    /**
     * @namespace
     */
var CAAT= CAAT || {};
