CAAT.Module({
    defines : "CAAT.Module.TexturePacker.TextureElement",
    extendsWith : {

        inverted:   false,
        image:      null,
        u:          0,
        v:          0,
        glTexture:  null
    }
});
