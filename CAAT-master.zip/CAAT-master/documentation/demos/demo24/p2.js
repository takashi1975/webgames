function ff1(ctx) {


ctx.fillStyle='#f2cc99';
ctx.beginPath();
ctx.moveTo(69.000000,18.000000);
  ctx.lineTo(82.000000,8.000000);
  ctx.lineTo(99.000000,3.000000);
  ctx.lineTo(118.000000,5.000000);
  ctx.lineTo(135.000000,12.000000);
  ctx.lineTo(149.000000,21.000000);
  ctx.lineTo(156.000000,13.000000);
  ctx.lineTo(165.000000,9.000000);
  ctx.lineTo(177.000000,13.000000);
  ctx.lineTo(183.000000,28.000000);
  ctx.lineTo(180.000000,50.000000);
  ctx.lineTo(164.000000,91.000000);
  ctx.lineTo(155.000000,107.000000);
  ctx.lineTo(154.000000,114.000000);
  ctx.lineTo(151.000000,121.000000);
  ctx.lineTo(141.000000,127.000000);
  ctx.lineTo(139.000000,136.000000);
  ctx.lineTo(155.000000,206.000000);
  ctx.lineTo(157.000000,251.000000);
  ctx.lineTo(126.000000,342.000000);
  ctx.lineTo(133.000000,357.000000);
  ctx.lineTo(128.000000,376.000000);
  ctx.lineTo(83.000000,376.000000);
  ctx.lineTo(75.000000,368.000000);
  ctx.lineTo(67.000000,350.000000);
  ctx.lineTo(61.000000,350.000000);
  ctx.lineTo(53.000000,369.000000);
  ctx.lineTo(4.000000,369.000000);
  ctx.lineTo(2.000000,361.000000);
  ctx.lineTo(5.000000,354.000000);
  ctx.lineTo(12.000000,342.000000);
  ctx.lineTo(16.000000,321.000000);
  ctx.lineTo(4.000000,257.000000);
  ctx.lineTo(4.000000,244.000000);
  ctx.lineTo(7.000000,218.000000);
  ctx.lineTo(9.000000,179.000000);
  ctx.lineTo(26.000000,127.000000);
  ctx.lineTo(43.000000,93.000000);
  ctx.lineTo(32.000000,77.000000);
  ctx.lineTo(30.000000,70.000000);
  ctx.lineTo(24.000000,67.000000);
  ctx.lineTo(16.000000,49.000000);
  ctx.lineTo(17.000000,35.000000);
  ctx.lineTo(18.000000,23.000000);
  ctx.lineTo(30.000000,12.000000);
  ctx.lineTo(40.000000,7.000000);
  ctx.lineTo(53.000000,7.000000);
  ctx.lineTo(62.000000,12.000000);
  ctx.lineTo(69.000000,18.000000);
ctx.fill();




ctx.fillStyle='#e5b27f';
ctx.beginPath();
ctx.moveTo(142.000000,79.000000);
  ctx.lineTo(136.000000,74.000000);
  ctx.lineTo(138.000000,82.000000);
  ctx.lineTo(133.000000,78.000000);
  ctx.lineTo(133.000000,84.000000);
  ctx.lineTo(127.000000,78.000000);
  ctx.lineTo(128.000000,85.000000);
  ctx.lineTo(124.000000,80.000000);
  ctx.lineTo(125.000000,87.000000);
  ctx.lineTo(119.000000,82.000000);
  ctx.lineTo(119.000000,90.000000);
  ctx.lineTo(125.000000,99.000000);
  ctx.lineTo(125.000000,96.000000);
  ctx.lineTo(128.000000,100.000000);
  ctx.lineTo(128.000000,94.000000);
  ctx.lineTo(131.000000,98.000000);
  ctx.lineTo(132.000000,93.000000);
  ctx.lineTo(135.000000,97.000000);
  ctx.lineTo(136.000000,93.000000);
  ctx.lineTo(138.000000,97.000000);
  ctx.lineTo(139.000000,94.000000);
  ctx.lineTo(141.000000,98.000000);
  ctx.lineTo(143.000000,94.000000);
  ctx.lineTo(144.000000,85.000000);
  ctx.lineTo(142.000000,79.000000);
ctx.fill();




ctx.fillStyle='#eb8080';
ctx.beginPath();
ctx.moveTo(127.000000,101.000000);
  ctx.lineTo(132.000000,100.000000);
  ctx.lineTo(137.000000,99.000000);
  ctx.lineTo(144.000000,101.000000);
  ctx.lineTo(143.000000,105.000000);
  ctx.lineTo(135.000000,110.000000);
  ctx.lineTo(127.000000,101.000000);
ctx.fill();




ctx.fillStyle='#f2cc99';
ctx.beginPath();
ctx.moveTo(178.000000,229.000000);
  ctx.lineTo(157.000000,248.000000);
  ctx.lineTo(139.000000,296.000000);
  ctx.lineTo(126.000000,349.000000);
  ctx.lineTo(137.000000,356.000000);
  ctx.lineTo(158.000000,357.000000);
  ctx.lineTo(183.000000,342.000000);
  ctx.lineTo(212.000000,332.000000);
  ctx.lineTo(235.000000,288.000000);
  ctx.lineTo(235.000000,261.000000);
  ctx.lineTo(228.000000,252.000000);
  ctx.lineTo(212.000000,250.000000);
  ctx.lineTo(188.000000,251.000000);
  ctx.lineTo(178.000000,229.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(56.000000,229.000000);
  ctx.lineTo(48.000000,241.000000);
  ctx.lineTo(48.000000,250.000000);
  ctx.lineTo(57.000000,281.000000);
  ctx.lineTo(63.000000,325.000000);
  ctx.lineTo(71.000000,338.000000);
  ctx.lineTo(81.000000,315.000000);
  ctx.lineTo(76.000000,321.000000);
  ctx.lineTo(79.000000,311.000000);
  ctx.lineTo(83.000000,301.000000);
  ctx.lineTo(75.000000,308.000000);
  ctx.lineTo(80.000000,298.000000);
  ctx.lineTo(73.000000,303.000000);
  ctx.lineTo(76.000000,296.000000);
  ctx.lineTo(71.000000,298.000000);
  ctx.lineTo(74.000000,292.000000);
  ctx.lineTo(69.000000,293.000000);
  ctx.lineTo(74.000000,284.000000);
  ctx.lineTo(78.000000,278.000000);
  ctx.lineTo(71.000000,278.000000);
  ctx.lineTo(74.000000,274.000000);
  ctx.lineTo(68.000000,273.000000);
  ctx.lineTo(70.000000,268.000000);
  ctx.lineTo(66.000000,267.000000);
  ctx.lineTo(68.000000,261.000000);
  ctx.lineTo(60.000000,266.000000);
  ctx.lineTo(62.000000,259.000000);
  ctx.lineTo(65.000000,253.000000);
  ctx.lineTo(57.000000,258.000000);
  ctx.lineTo(59.000000,251.000000);
  ctx.lineTo(55.000000,254.000000);
  ctx.lineTo(55.000000,248.000000);
  ctx.lineTo(60.000000,237.000000);
  ctx.lineTo(54.000000,240.000000);
  ctx.lineTo(58.000000,234.000000);
  ctx.lineTo(54.000000,236.000000);
  ctx.lineTo(56.000000,229.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(74.000000,363.000000);
  ctx.lineTo(79.000000,368.000000);
  ctx.lineTo(81.000000,368.000000);
  ctx.lineTo(85.000000,362.000000);
  ctx.lineTo(89.000000,363.000000);
  ctx.lineTo(92.000000,370.000000);
  ctx.lineTo(96.000000,373.000000);
  ctx.lineTo(101.000000,372.000000);
  ctx.lineTo(108.000000,361.000000);
  ctx.lineTo(110.000000,371.000000);
  ctx.lineTo(113.000000,373.000000);
  ctx.lineTo(116.000000,371.000000);
  ctx.lineTo(120.000000,358.000000);
  ctx.lineTo(122.000000,363.000000);
  ctx.lineTo(123.000000,371.000000);
  ctx.lineTo(126.000000,371.000000);
  ctx.lineTo(129.000000,367.000000);
  ctx.lineTo(132.000000,357.000000);
  ctx.lineTo(135.000000,361.000000);
  ctx.lineTo(130.000000,376.000000);
  ctx.lineTo(127.000000,377.000000);
  ctx.lineTo(94.000000,378.000000);
  ctx.lineTo(84.000000,376.000000);
  ctx.lineTo(76.000000,371.000000);
  ctx.lineTo(74.000000,363.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(212.000000,250.000000);
  ctx.lineTo(219.000000,251.000000);
  ctx.lineTo(228.000000,258.000000);
  ctx.lineTo(236.000000,270.000000);
  ctx.lineTo(235.000000,287.000000);
  ctx.lineTo(225.000000,304.000000);
  ctx.lineTo(205.000000,332.000000);
  ctx.lineTo(177.000000,343.000000);
  ctx.lineTo(171.000000,352.000000);
  ctx.lineTo(158.000000,357.000000);
  ctx.lineTo(166.000000,352.000000);
  ctx.lineTo(168.000000,346.000000);
  ctx.lineTo(168.000000,339.000000);
  ctx.lineTo(165.000000,333.000000);
  ctx.lineTo(155.000000,327.000000);
  ctx.lineTo(155.000000,323.000000);
  ctx.lineTo(161.000000,320.000000);
  ctx.lineTo(165.000000,316.000000);
  ctx.lineTo(169.000000,316.000000);
  ctx.lineTo(167.000000,312.000000);
  ctx.lineTo(171.000000,313.000000);
  ctx.lineTo(168.000000,308.000000);
  ctx.lineTo(173.000000,309.000000);
  ctx.lineTo(170.000000,306.000000);
  ctx.lineTo(177.000000,306.000000);
  ctx.lineTo(175.000000,308.000000);
  ctx.lineTo(177.000000,311.000000);
  ctx.lineTo(174.000000,311.000000);
  ctx.lineTo(176.000000,316.000000);
  ctx.lineTo(171.000000,315.000000);
  ctx.lineTo(174.000000,319.000000);
  ctx.lineTo(168.000000,320.000000);
  ctx.lineTo(168.000000,323.000000);
  ctx.lineTo(175.000000,327.000000);
  ctx.lineTo(179.000000,332.000000);
  ctx.lineTo(183.000000,326.000000);
  ctx.lineTo(184.000000,332.000000);
  ctx.lineTo(189.000000,323.000000);
  ctx.lineTo(190.000000,328.000000);
  ctx.lineTo(194.000000,320.000000);
  ctx.lineTo(194.000000,325.000000);
  ctx.lineTo(199.000000,316.000000);
  ctx.lineTo(201.000000,320.000000);
  ctx.lineTo(204.000000,313.000000);
  ctx.lineTo(206.000000,316.000000);
  ctx.lineTo(208.000000,310.000000);
  ctx.lineTo(211.000000,305.000000);
  ctx.lineTo(219.000000,298.000000);
  ctx.lineTo(226.000000,288.000000);
  ctx.lineTo(229.000000,279.000000);
  ctx.lineTo(228.000000,266.000000);
  ctx.lineTo(224.000000,259.000000);
  ctx.lineTo(217.000000,253.000000);
  ctx.lineTo(212.000000,250.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(151.000000,205.000000);
  ctx.lineTo(151.000000,238.000000);
  ctx.lineTo(149.000000,252.000000);
  ctx.lineTo(141.000000,268.000000);
  ctx.lineTo(128.000000,282.000000);
  ctx.lineTo(121.000000,301.000000);
  ctx.lineTo(130.000000,300.000000);
  ctx.lineTo(126.000000,313.000000);
  ctx.lineTo(118.000000,324.000000);
  ctx.lineTo(116.000000,337.000000);
  ctx.lineTo(120.000000,346.000000);
  ctx.lineTo(133.000000,352.000000);
  ctx.lineTo(133.000000,340.000000);
  ctx.lineTo(137.000000,333.000000);
  ctx.lineTo(145.000000,329.000000);
  ctx.lineTo(156.000000,327.000000);
  ctx.lineTo(153.000000,319.000000);
  ctx.lineTo(153.000000,291.000000);
  ctx.lineTo(157.000000,271.000000);
  ctx.lineTo(170.000000,259.000000);
  ctx.lineTo(178.000000,277.000000);
  ctx.lineTo(193.000000,250.000000);
  ctx.lineTo(174.000000,216.000000);
  ctx.lineTo(151.000000,205.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(78.000000,127.000000);
  ctx.lineTo(90.000000,142.000000);
  ctx.lineTo(95.000000,155.000000);
  ctx.lineTo(108.000000,164.000000);
  ctx.lineTo(125.000000,167.000000);
  ctx.lineTo(139.000000,175.000000);
  ctx.lineTo(150.000000,206.000000);
  ctx.lineTo(152.000000,191.000000);
  ctx.lineTo(141.000000,140.000000);
  ctx.lineTo(121.000000,148.000000);
  ctx.lineTo(100.000000,136.000000);
  ctx.lineTo(78.000000,127.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(21.000000,58.000000);
  ctx.lineTo(35.000000,63.000000);
  ctx.lineTo(38.000000,68.000000);
  ctx.lineTo(32.000000,69.000000);
  ctx.lineTo(42.000000,74.000000);
  ctx.lineTo(40.000000,79.000000);
  ctx.lineTo(47.000000,80.000000);
  ctx.lineTo(54.000000,83.000000);
  ctx.lineTo(45.000000,94.000000);
  ctx.lineTo(34.000000,81.000000);
  ctx.lineTo(32.000000,73.000000);
  ctx.lineTo(24.000000,66.000000);
  ctx.lineTo(21.000000,58.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(71.000000,34.000000);
  ctx.lineTo(67.000000,34.000000);
  ctx.lineTo(66.000000,27.000000);
  ctx.lineTo(59.000000,24.000000);
  ctx.lineTo(54.000000,17.000000);
  ctx.lineTo(48.000000,17.000000);
  ctx.lineTo(39.000000,22.000000);
  ctx.lineTo(30.000000,26.000000);
  ctx.lineTo(28.000000,31.000000);
  ctx.lineTo(31.000000,39.000000);
  ctx.lineTo(38.000000,46.000000);
  ctx.lineTo(29.000000,45.000000);
  ctx.lineTo(36.000000,54.000000);
  ctx.lineTo(41.000000,61.000000);
  ctx.lineTo(41.000000,70.000000);
  ctx.lineTo(50.000000,69.000000);
  ctx.lineTo(54.000000,71.000000);
  ctx.lineTo(55.000000,58.000000);
  ctx.lineTo(67.000000,52.000000);
  ctx.lineTo(76.000000,43.000000);
  ctx.lineTo(76.000000,39.000000);
  ctx.lineTo(68.000000,44.000000);
  ctx.lineTo(71.000000,34.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(139.000000,74.000000);
  ctx.lineTo(141.000000,83.000000);
  ctx.lineTo(143.000000,89.000000);
  ctx.lineTo(144.000000,104.000000);
  ctx.lineTo(148.000000,104.000000);
  ctx.lineTo(155.000000,106.000000);
  ctx.lineTo(154.000000,86.000000);
  ctx.lineTo(157.000000,77.000000);
  ctx.lineTo(155.000000,72.000000);
  ctx.lineTo(150.000000,77.000000);
  ctx.lineTo(144.000000,77.000000);
  ctx.lineTo(139.000000,74.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(105.000000,44.000000);
  ctx.lineTo(102.000000,53.000000);
  ctx.lineTo(108.000000,58.000000);
  ctx.lineTo(111.000000,62.000000);
  ctx.lineTo(112.000000,55.000000);
  ctx.lineTo(105.000000,44.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(141.000000,48.000000);
  ctx.lineTo(141.000000,54.000000);
  ctx.lineTo(144.000000,58.000000);
  ctx.lineTo(139.000000,62.000000);
  ctx.lineTo(137.000000,66.000000);
  ctx.lineTo(136.000000,59.000000);
  ctx.lineTo(137.000000,52.000000);
  ctx.lineTo(141.000000,48.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(98.000000,135.000000);
  ctx.lineTo(104.000000,130.000000);
  ctx.lineTo(105.000000,134.000000);
  ctx.lineTo(108.000000,132.000000);
  ctx.lineTo(108.000000,135.000000);
  ctx.lineTo(112.000000,134.000000);
  ctx.lineTo(113.000000,137.000000);
  ctx.lineTo(116.000000,136.000000);
  ctx.lineTo(116.000000,139.000000);
  ctx.lineTo(119.000000,139.000000);
  ctx.lineTo(124.000000,141.000000);
  ctx.lineTo(128.000000,140.000000);
  ctx.lineTo(133.000000,138.000000);
  ctx.lineTo(140.000000,133.000000);
  ctx.lineTo(139.000000,140.000000);
  ctx.lineTo(126.000000,146.000000);
  ctx.lineTo(104.000000,144.000000);
  ctx.lineTo(98.000000,135.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(97.000000,116.000000);
  ctx.lineTo(103.000000,119.000000);
  ctx.lineTo(103.000000,116.000000);
  ctx.lineTo(111.000000,118.000000);
  ctx.lineTo(116.000000,117.000000);
  ctx.lineTo(122.000000,114.000000);
  ctx.lineTo(127.000000,107.000000);
  ctx.lineTo(135.000000,111.000000);
  ctx.lineTo(142.000000,107.000000);
  ctx.lineTo(141.000000,114.000000);
  ctx.lineTo(145.000000,118.000000);
  ctx.lineTo(149.000000,121.000000);
  ctx.lineTo(145.000000,125.000000);
  ctx.lineTo(140.000000,124.000000);
  ctx.lineTo(127.000000,121.000000);
  ctx.lineTo(113.000000,125.000000);
  ctx.lineTo(100.000000,124.000000);
  ctx.lineTo(97.000000,116.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(147.000000,33.000000);
  ctx.lineTo(152.000000,35.000000);
  ctx.lineTo(157.000000,34.000000);
  ctx.lineTo(153.000000,31.000000);
  ctx.lineTo(160.000000,31.000000);
  ctx.lineTo(156.000000,28.000000);
  ctx.lineTo(161.000000,28.000000);
  ctx.lineTo(159.000000,24.000000);
  ctx.lineTo(163.000000,25.000000);
  ctx.lineTo(163.000000,21.000000);
  ctx.lineTo(165.000000,22.000000);
  ctx.lineTo(170.000000,23.000000);
  ctx.lineTo(167.000000,17.000000);
  ctx.lineTo(172.000000,21.000000);
  ctx.lineTo(174.000000,18.000000);
  ctx.lineTo(175.000000,23.000000);
  ctx.lineTo(176.000000,22.000000);
  ctx.lineTo(177.000000,28.000000);
  ctx.lineTo(177.000000,33.000000);
  ctx.lineTo(174.000000,37.000000);
  ctx.lineTo(176.000000,39.000000);
  ctx.lineTo(174.000000,44.000000);
  ctx.lineTo(171.000000,49.000000);
  ctx.lineTo(168.000000,53.000000);
  ctx.lineTo(164.000000,57.000000);
  ctx.lineTo(159.000000,68.000000);
  ctx.lineTo(156.000000,70.000000);
  ctx.lineTo(154.000000,60.000000);
  ctx.lineTo(150.000000,51.000000);
  ctx.lineTo(146.000000,43.000000);
  ctx.lineTo(144.000000,35.000000);
  ctx.lineTo(147.000000,33.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(85.000000,72.000000);
  ctx.lineTo(89.000000,74.000000);
  ctx.lineTo(93.000000,75.000000);
  ctx.lineTo(100.000000,76.000000);
  ctx.lineTo(105.000000,75.000000);
  ctx.lineTo(102.000000,79.000000);
  ctx.lineTo(94.000000,79.000000);
  ctx.lineTo(88.000000,76.000000);
  ctx.lineTo(85.000000,72.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(86.000000,214.000000);
  ctx.lineTo(79.000000,221.000000);
  ctx.lineTo(76.000000,232.000000);
  ctx.lineTo(82.000000,225.000000);
  ctx.lineTo(78.000000,239.000000);
  ctx.lineTo(82.000000,234.000000);
  ctx.lineTo(78.000000,245.000000);
  ctx.lineTo(81.000000,243.000000);
  ctx.lineTo(79.000000,255.000000);
  ctx.lineTo(84.000000,250.000000);
  ctx.lineTo(84.000000,267.000000);
  ctx.lineTo(87.000000,254.000000);
  ctx.lineTo(90.000000,271.000000);
  ctx.lineTo(90.000000,257.000000);
  ctx.lineTo(95.000000,271.000000);
  ctx.lineTo(93.000000,256.000000);
  ctx.lineTo(95.000000,249.000000);
  ctx.lineTo(92.000000,252.000000);
  ctx.lineTo(93.000000,243.000000);
  ctx.lineTo(89.000000,253.000000);
  ctx.lineTo(89.000000,241.000000);
  ctx.lineTo(86.000000,250.000000);
  ctx.lineTo(87.000000,236.000000);
  ctx.lineTo(83.000000,245.000000);
  ctx.lineTo(87.000000,231.000000);
  ctx.lineTo(82.000000,231.000000);
  ctx.lineTo(90.000000,219.000000);
  ctx.lineTo(84.000000,221.000000);
  ctx.lineTo(86.000000,214.000000);
ctx.fill();




ctx.fillStyle='#ffcc7f';
ctx.beginPath();
ctx.moveTo(93.000000,68.000000);
  ctx.lineTo(96.000000,72.000000);
  ctx.lineTo(100.000000,73.000000);
  ctx.lineTo(106.000000,72.000000);
  ctx.lineTo(108.000000,66.000000);
  ctx.lineTo(105.000000,63.000000);
  ctx.lineTo(100.000000,62.000000);
  ctx.lineTo(93.000000,68.000000);
ctx.fill();




ctx.fillStyle='#ffcc7f';
ctx.beginPath();
ctx.moveTo(144.000000,64.000000);
  ctx.lineTo(142.000000,68.000000);
  ctx.lineTo(142.000000,73.000000);
  ctx.lineTo(146.000000,74.000000);
  ctx.lineTo(150.000000,73.000000);
  ctx.lineTo(154.000000,64.000000);
  ctx.lineTo(149.000000,62.000000);
  ctx.lineTo(144.000000,64.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(57.000000,91.000000);
  ctx.lineTo(42.000000,111.000000);
  ctx.lineTo(52.000000,105.000000);
  ctx.lineTo(41.000000,117.000000);
  ctx.lineTo(53.000000,112.000000);
  ctx.lineTo(46.000000,120.000000);
  ctx.lineTo(53.000000,116.000000);
  ctx.lineTo(50.000000,124.000000);
  ctx.lineTo(57.000000,119.000000);
  ctx.lineTo(55.000000,127.000000);
  ctx.lineTo(61.000000,122.000000);
  ctx.lineTo(60.000000,130.000000);
  ctx.lineTo(67.000000,126.000000);
  ctx.lineTo(66.000000,134.000000);
  ctx.lineTo(71.000000,129.000000);
  ctx.lineTo(72.000000,136.000000);
  ctx.lineTo(77.000000,130.000000);
  ctx.lineTo(76.000000,137.000000);
  ctx.lineTo(80.000000,133.000000);
  ctx.lineTo(82.000000,138.000000);
  ctx.lineTo(86.000000,135.000000);
  ctx.lineTo(96.000000,135.000000);
  ctx.lineTo(94.000000,129.000000);
  ctx.lineTo(86.000000,124.000000);
  ctx.lineTo(83.000000,117.000000);
  ctx.lineTo(77.000000,123.000000);
  ctx.lineTo(79.000000,117.000000);
  ctx.lineTo(73.000000,120.000000);
  ctx.lineTo(75.000000,112.000000);
  ctx.lineTo(68.000000,116.000000);
  ctx.lineTo(71.000000,111.000000);
  ctx.lineTo(65.000000,114.000000);
  ctx.lineTo(69.000000,107.000000);
  ctx.lineTo(63.000000,110.000000);
  ctx.lineTo(68.000000,102.000000);
  ctx.lineTo(61.000000,107.000000);
  ctx.lineTo(66.000000,98.000000);
  ctx.lineTo(61.000000,103.000000);
  ctx.lineTo(63.000000,97.000000);
  ctx.lineTo(57.000000,99.000000);
  ctx.lineTo(57.000000,91.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(83.000000,79.000000);
  ctx.lineTo(76.000000,79.000000);
  ctx.lineTo(67.000000,82.000000);
  ctx.lineTo(75.000000,83.000000);
  ctx.lineTo(65.000000,88.000000);
  ctx.lineTo(76.000000,87.000000);
  ctx.lineTo(65.000000,92.000000);
  ctx.lineTo(76.000000,91.000000);
  ctx.lineTo(68.000000,96.000000);
  ctx.lineTo(77.000000,95.000000);
  ctx.lineTo(70.000000,99.000000);
  ctx.lineTo(80.000000,98.000000);
  ctx.lineTo(72.000000,104.000000);
  ctx.lineTo(80.000000,102.000000);
  ctx.lineTo(76.000000,108.000000);
  ctx.lineTo(85.000000,103.000000);
  ctx.lineTo(92.000000,101.000000);
  ctx.lineTo(87.000000,98.000000);
  ctx.lineTo(93.000000,96.000000);
  ctx.lineTo(86.000000,94.000000);
  ctx.lineTo(91.000000,93.000000);
  ctx.lineTo(85.000000,91.000000);
  ctx.lineTo(93.000000,89.000000);
  ctx.lineTo(99.000000,89.000000);
  ctx.lineTo(105.000000,93.000000);
  ctx.lineTo(107.000000,85.000000);
  ctx.lineTo(102.000000,82.000000);
  ctx.lineTo(92.000000,80.000000);
  ctx.lineTo(83.000000,79.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(109.000000,77.000000);
  ctx.lineTo(111.000000,83.000000);
  ctx.lineTo(109.000000,89.000000);
  ctx.lineTo(113.000000,94.000000);
  ctx.lineTo(117.000000,90.000000);
  ctx.lineTo(117.000000,81.000000);
  ctx.lineTo(114.000000,78.000000);
  ctx.lineTo(109.000000,77.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(122.000000,128.000000);
  ctx.lineTo(127.000000,126.000000);
  ctx.lineTo(134.000000,127.000000);
  ctx.lineTo(136.000000,129.000000);
  ctx.lineTo(134.000000,130.000000);
  ctx.lineTo(130.000000,128.000000);
  ctx.lineTo(124.000000,129.000000);
  ctx.lineTo(122.000000,128.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(78.000000,27.000000);
  ctx.lineTo(82.000000,32.000000);
  ctx.lineTo(80.000000,33.000000);
  ctx.lineTo(82.000000,36.000000);
  ctx.lineTo(78.000000,37.000000);
  ctx.lineTo(82.000000,40.000000);
  ctx.lineTo(78.000000,42.000000);
  ctx.lineTo(81.000000,46.000000);
  ctx.lineTo(76.000000,47.000000);
  ctx.lineTo(78.000000,49.000000);
  ctx.lineTo(74.000000,50.000000);
  ctx.lineTo(82.000000,52.000000);
  ctx.lineTo(87.000000,50.000000);
  ctx.lineTo(83.000000,48.000000);
  ctx.lineTo(91.000000,46.000000);
  ctx.lineTo(86.000000,45.000000);
  ctx.lineTo(91.000000,42.000000);
  ctx.lineTo(88.000000,40.000000);
  ctx.lineTo(92.000000,37.000000);
  ctx.lineTo(86.000000,34.000000);
  ctx.lineTo(90.000000,31.000000);
  ctx.lineTo(86.000000,29.000000);
  ctx.lineTo(89.000000,26.000000);
  ctx.lineTo(78.000000,27.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(82.000000,17.000000);
  ctx.lineTo(92.000000,20.000000);
  ctx.lineTo(79.000000,21.000000);
  ctx.lineTo(90.000000,25.000000);
  ctx.lineTo(81.000000,25.000000);
  ctx.lineTo(94.000000,28.000000);
  ctx.lineTo(93.000000,26.000000);
  ctx.lineTo(101.000000,30.000000);
  ctx.lineTo(101.000000,26.000000);
  ctx.lineTo(107.000000,33.000000);
  ctx.lineTo(108.000000,28.000000);
  ctx.lineTo(111.000000,40.000000);
  ctx.lineTo(113.000000,34.000000);
  ctx.lineTo(115.000000,45.000000);
  ctx.lineTo(117.000000,39.000000);
  ctx.lineTo(119.000000,54.000000);
  ctx.lineTo(121.000000,46.000000);
  ctx.lineTo(124.000000,58.000000);
  ctx.lineTo(126.000000,47.000000);
  ctx.lineTo(129.000000,59.000000);
  ctx.lineTo(130.000000,49.000000);
  ctx.lineTo(134.000000,58.000000);
  ctx.lineTo(133.000000,44.000000);
  ctx.lineTo(137.000000,48.000000);
  ctx.lineTo(133.000000,37.000000);
  ctx.lineTo(137.000000,40.000000);
  ctx.lineTo(133.000000,32.000000);
  ctx.lineTo(126.000000,20.000000);
  ctx.lineTo(135.000000,26.000000);
  ctx.lineTo(132.000000,19.000000);
  ctx.lineTo(138.000000,23.000000);
  ctx.lineTo(135.000000,17.000000);
  ctx.lineTo(142.000000,18.000000);
  ctx.lineTo(132.000000,11.000000);
  ctx.lineTo(116.000000,6.000000);
  ctx.lineTo(94.000000,6.000000);
  ctx.lineTo(78.000000,11.000000);
  ctx.lineTo(92.000000,12.000000);
  ctx.lineTo(80.000000,14.000000);
  ctx.lineTo(90.000000,16.000000);
  ctx.lineTo(82.000000,17.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(142.000000,234.000000);
  ctx.lineTo(132.000000,227.000000);
  ctx.lineTo(124.000000,223.000000);
  ctx.lineTo(115.000000,220.000000);
  ctx.lineTo(110.000000,225.000000);
  ctx.lineTo(118.000000,224.000000);
  ctx.lineTo(127.000000,229.000000);
  ctx.lineTo(135.000000,236.000000);
  ctx.lineTo(122.000000,234.000000);
  ctx.lineTo(115.000000,237.000000);
  ctx.lineTo(113.000000,242.000000);
  ctx.lineTo(121.000000,238.000000);
  ctx.lineTo(139.000000,243.000000);
  ctx.lineTo(121.000000,245.000000);
  ctx.lineTo(111.000000,254.000000);
  ctx.lineTo(95.000000,254.000000);
  ctx.lineTo(102.000000,244.000000);
  ctx.lineTo(104.000000,235.000000);
  ctx.lineTo(110.000000,229.000000);
  ctx.lineTo(100.000000,231.000000);
  ctx.lineTo(104.000000,224.000000);
  ctx.lineTo(113.000000,216.000000);
  ctx.lineTo(122.000000,215.000000);
  ctx.lineTo(132.000000,217.000000);
  ctx.lineTo(141.000000,224.000000);
  ctx.lineTo(145.000000,230.000000);
  ctx.lineTo(149.000000,240.000000);
  ctx.lineTo(142.000000,234.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(115.000000,252.000000);
  ctx.lineTo(125.000000,248.000000);
  ctx.lineTo(137.000000,249.000000);
  ctx.lineTo(143.000000,258.000000);
  ctx.lineTo(134.000000,255.000000);
  ctx.lineTo(125.000000,254.000000);
  ctx.lineTo(115.000000,252.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(114.000000,212.000000);
  ctx.lineTo(130.000000,213.000000);
  ctx.lineTo(140.000000,219.000000);
  ctx.lineTo(147.000000,225.000000);
  ctx.lineTo(144.000000,214.000000);
  ctx.lineTo(137.000000,209.000000);
  ctx.lineTo(128.000000,207.000000);
  ctx.lineTo(114.000000,212.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(102.000000,263.000000);
  ctx.lineTo(108.000000,258.000000);
  ctx.lineTo(117.000000,257.000000);
  ctx.lineTo(131.000000,258.000000);
  ctx.lineTo(116.000000,260.000000);
  ctx.lineTo(109.000000,265.000000);
  ctx.lineTo(102.000000,263.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(51.000000,241.000000);
  ctx.lineTo(35.000000,224.000000);
  ctx.lineTo(40.000000,238.000000);
  ctx.lineTo(23.000000,224.000000);
  ctx.lineTo(31.000000,242.000000);
  ctx.lineTo(19.000000,239.000000);
  ctx.lineTo(28.000000,247.000000);
  ctx.lineTo(17.000000,246.000000);
  ctx.lineTo(25.000000,250.000000);
  ctx.lineTo(37.000000,254.000000);
  ctx.lineTo(39.000000,263.000000);
  ctx.lineTo(44.000000,271.000000);
  ctx.lineTo(47.000000,294.000000);
  ctx.lineTo(48.000000,317.000000);
  ctx.lineTo(51.000000,328.000000);
  ctx.lineTo(60.000000,351.000000);
  ctx.lineTo(60.000000,323.000000);
  ctx.lineTo(53.000000,262.000000);
  ctx.lineTo(47.000000,246.000000);
  ctx.lineTo(51.000000,241.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(2.000000,364.000000);
  ctx.lineTo(9.000000,367.000000);
  ctx.lineTo(14.000000,366.000000);
  ctx.lineTo(18.000000,355.000000);
  ctx.lineTo(20.000000,364.000000);
  ctx.lineTo(26.000000,366.000000);
  ctx.lineTo(31.000000,357.000000);
  ctx.lineTo(35.000000,364.000000);
  ctx.lineTo(39.000000,364.000000);
  ctx.lineTo(42.000000,357.000000);
  ctx.lineTo(47.000000,363.000000);
  ctx.lineTo(53.000000,360.000000);
  ctx.lineTo(59.000000,357.000000);
  ctx.lineTo(54.000000,369.000000);
  ctx.lineTo(7.000000,373.000000);
  ctx.lineTo(2.000000,364.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(7.000000,349.000000);
  ctx.lineTo(19.000000,345.000000);
  ctx.lineTo(25.000000,339.000000);
  ctx.lineTo(18.000000,341.000000);
  ctx.lineTo(23.000000,333.000000);
  ctx.lineTo(28.000000,326.000000);
  ctx.lineTo(23.000000,326.000000);
  ctx.lineTo(27.000000,320.000000);
  ctx.lineTo(23.000000,316.000000);
  ctx.lineTo(25.000000,311.000000);
  ctx.lineTo(20.000000,298.000000);
  ctx.lineTo(15.000000,277.000000);
  ctx.lineTo(12.000000,264.000000);
  ctx.lineTo(9.000000,249.000000);
  ctx.lineTo(10.000000,223.000000);
  ctx.lineTo(3.000000,248.000000);
  ctx.lineTo(5.000000,261.000000);
  ctx.lineTo(15.000000,307.000000);
  ctx.lineTo(17.000000,326.000000);
  ctx.lineTo(11.000000,343.000000);
  ctx.lineTo(7.000000,349.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(11.000000,226.000000);
  ctx.lineTo(15.000000,231.000000);
  ctx.lineTo(25.000000,236.000000);
  ctx.lineTo(18.000000,227.000000);
  ctx.lineTo(11.000000,226.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(13.000000,214.000000);
  ctx.lineTo(19.000000,217.000000);
  ctx.lineTo(32.000000,227.000000);
  ctx.lineTo(23.000000,214.000000);
  ctx.lineTo(16.000000,208.000000);
  ctx.lineTo(15.000000,190.000000);
  ctx.lineTo(24.000000,148.000000);
  ctx.lineTo(31.000000,121.000000);
  ctx.lineTo(24.000000,137.000000);
  ctx.lineTo(14.000000,170.000000);
  ctx.lineTo(8.000000,189.000000);
  ctx.lineTo(13.000000,214.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(202.000000,254.000000);
  ctx.lineTo(195.000000,258.000000);
  ctx.lineTo(199.000000,260.000000);
  ctx.lineTo(193.000000,263.000000);
  ctx.lineTo(197.000000,263.000000);
  ctx.lineTo(190.000000,268.000000);
  ctx.lineTo(196.000000,268.000000);
  ctx.lineTo(191.000000,273.000000);
  ctx.lineTo(188.000000,282.000000);
  ctx.lineTo(200.000000,272.000000);
  ctx.lineTo(194.000000,272.000000);
  ctx.lineTo(201.000000,266.000000);
  ctx.lineTo(197.000000,265.000000);
  ctx.lineTo(204.000000,262.000000);
  ctx.lineTo(200.000000,258.000000);
  ctx.lineTo(204.000000,256.000000);
  ctx.lineTo(202.000000,254.000000);
ctx.fill();




ctx.fillStyle='#845433';
ctx.beginPath();
ctx.moveTo(151.000000,213.000000);
  ctx.lineTo(165.000000,212.000000);
  ctx.lineTo(179.000000,225.000000);
  ctx.lineTo(189.000000,246.000000);
  ctx.lineTo(187.000000,262.000000);
  ctx.lineTo(179.000000,275.000000);
  ctx.lineTo(176.000000,263.000000);
  ctx.lineTo(177.000000,247.000000);
  ctx.lineTo(171.000000,233.000000);
  ctx.lineTo(163.000000,230.000000);
  ctx.lineTo(165.000000,251.000000);
  ctx.lineTo(157.000000,264.000000);
  ctx.lineTo(146.000000,298.000000);
  ctx.lineTo(145.000000,321.000000);
  ctx.lineTo(133.000000,326.000000);
  ctx.lineTo(143.000000,285.000000);
  ctx.lineTo(154.000000,260.000000);
  ctx.lineTo(153.000000,240.000000);
  ctx.lineTo(151.000000,213.000000);
ctx.fill();




ctx.fillStyle='#845433';
ctx.beginPath();
ctx.moveTo(91.000000,132.000000);
  ctx.lineTo(95.000000,145.000000);
  ctx.lineTo(97.000000,154.000000);
  ctx.lineTo(104.000000,148.000000);
  ctx.lineTo(107.000000,155.000000);
  ctx.lineTo(109.000000,150.000000);
  ctx.lineTo(111.000000,158.000000);
  ctx.lineTo(115.000000,152.000000);
  ctx.lineTo(118.000000,159.000000);
  ctx.lineTo(120.000000,153.000000);
  ctx.lineTo(125.000000,161.000000);
  ctx.lineTo(126.000000,155.000000);
  ctx.lineTo(133.000000,164.000000);
  ctx.lineTo(132.000000,154.000000);
  ctx.lineTo(137.000000,163.000000);
  ctx.lineTo(137.000000,152.000000);
  ctx.lineTo(142.000000,163.000000);
  ctx.lineTo(147.000000,186.000000);
  ctx.lineTo(152.000000,192.000000);
  ctx.lineTo(148.000000,167.000000);
  ctx.lineTo(141.000000,143.000000);
  ctx.lineTo(124.000000,145.000000);
  ctx.lineTo(105.000000,143.000000);
  ctx.lineTo(91.000000,132.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(31.000000,57.000000);
  ctx.lineTo(23.000000,52.000000);
  ctx.lineTo(26.000000,51.000000);
  ctx.lineTo(20.000000,44.000000);
  ctx.lineTo(23.000000,42.000000);
  ctx.lineTo(21.000000,36.000000);
  ctx.lineTo(22.000000,29.000000);
  ctx.lineTo(25.000000,23.000000);
  ctx.lineTo(24.000000,32.000000);
  ctx.lineTo(30.000000,43.000000);
  ctx.lineTo(26.000000,41.000000);
  ctx.lineTo(30.000000,50.000000);
  ctx.lineTo(26.000000,48.000000);
  ctx.lineTo(31.000000,57.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(147.000000,21.000000);
  ctx.lineTo(149.000000,28.000000);
  ctx.lineTo(155.000000,21.000000);
  ctx.lineTo(161.000000,16.000000);
  ctx.lineTo(167.000000,14.000000);
  ctx.lineTo(175.000000,15.000000);
  ctx.lineTo(173.000000,11.000000);
  ctx.lineTo(161.000000,9.000000);
  ctx.lineTo(147.000000,21.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(181.000000,39.000000);
  ctx.lineTo(175.000000,51.000000);
  ctx.lineTo(169.000000,57.000000);
  ctx.lineTo(171.000000,65.000000);
  ctx.lineTo(165.000000,68.000000);
  ctx.lineTo(165.000000,75.000000);
  ctx.lineTo(160.000000,76.000000);
  ctx.lineTo(162.000000,91.000000);
  ctx.lineTo(171.000000,71.000000);
  ctx.lineTo(180.000000,51.000000);
  ctx.lineTo(181.000000,39.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(132.000000,346.000000);
  ctx.lineTo(139.000000,348.000000);
  ctx.lineTo(141.000000,346.000000);
  ctx.lineTo(142.000000,341.000000);
  ctx.lineTo(147.000000,342.000000);
  ctx.lineTo(143.000000,355.000000);
  ctx.lineTo(133.000000,350.000000);
  ctx.lineTo(132.000000,346.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(146.000000,355.000000);
  ctx.lineTo(151.000000,352.000000);
  ctx.lineTo(155.000000,348.000000);
  ctx.lineTo(157.000000,343.000000);
  ctx.lineTo(160.000000,349.000000);
  ctx.lineTo(151.000000,356.000000);
  ctx.lineTo(147.000000,357.000000);
  ctx.lineTo(146.000000,355.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(99.000000,266.000000);
  ctx.lineTo(100.000000,281.000000);
  ctx.lineTo(94.000000,305.000000);
  ctx.lineTo(86.000000,322.000000);
  ctx.lineTo(78.000000,332.000000);
  ctx.lineTo(72.000000,346.000000);
  ctx.lineTo(73.000000,331.000000);
  ctx.lineTo(91.000000,291.000000);
  ctx.lineTo(99.000000,266.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(20.000000,347.000000);
  ctx.lineTo(32.000000,342.000000);
  ctx.lineTo(45.000000,340.000000);
  ctx.lineTo(54.000000,345.000000);
  ctx.lineTo(45.000000,350.000000);
  ctx.lineTo(42.000000,353.000000);
  ctx.lineTo(38.000000,350.000000);
  ctx.lineTo(31.000000,353.000000);
  ctx.lineTo(29.000000,356.000000);
  ctx.lineTo(23.000000,350.000000);
  ctx.lineTo(19.000000,353.000000);
  ctx.lineTo(15.000000,349.000000);
  ctx.lineTo(20.000000,347.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(78.000000,344.000000);
  ctx.lineTo(86.000000,344.000000);
  ctx.lineTo(92.000000,349.000000);
  ctx.lineTo(88.000000,358.000000);
  ctx.lineTo(84.000000,352.000000);
  ctx.lineTo(78.000000,344.000000);
ctx.fill();




ctx.fillStyle='#9c826b';
ctx.beginPath();
ctx.moveTo(93.000000,347.000000);
  ctx.lineTo(104.000000,344.000000);
  ctx.lineTo(117.000000,345.000000);
  ctx.lineTo(124.000000,354.000000);
  ctx.lineTo(121.000000,357.000000);
  ctx.lineTo(116.000000,351.000000);
  ctx.lineTo(112.000000,351.000000);
  ctx.lineTo(108.000000,355.000000);
  ctx.lineTo(102.000000,351.000000);
  ctx.lineTo(93.000000,347.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(105.000000,12.000000);
  ctx.lineTo(111.000000,18.000000);
  ctx.lineTo(113.000000,24.000000);
  ctx.lineTo(113.000000,29.000000);
  ctx.lineTo(119.000000,34.000000);
  ctx.lineTo(116.000000,23.000000);
  ctx.lineTo(112.000000,16.000000);
  ctx.lineTo(105.000000,12.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(122.000000,27.000000);
  ctx.lineTo(125.000000,34.000000);
  ctx.lineTo(127.000000,43.000000);
  ctx.lineTo(128.000000,34.000000);
  ctx.lineTo(125.000000,29.000000);
  ctx.lineTo(122.000000,27.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(115.000000,13.000000);
  ctx.lineTo(122.000000,19.000000);
  ctx.lineTo(122.000000,15.000000);
  ctx.lineTo(113.000000,10.000000);
  ctx.lineTo(115.000000,13.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(116.000000,172.000000);
  ctx.lineTo(107.000000,182.000000);
  ctx.lineTo(98.000000,193.000000);
  ctx.lineTo(98.000000,183.000000);
  ctx.lineTo(90.000000,199.000000);
  ctx.lineTo(89.000000,189.000000);
  ctx.lineTo(84.000000,207.000000);
  ctx.lineTo(88.000000,206.000000);
  ctx.lineTo(87.000000,215.000000);
  ctx.lineTo(95.000000,206.000000);
  ctx.lineTo(93.000000,219.000000);
  ctx.lineTo(91.000000,230.000000);
  ctx.lineTo(98.000000,216.000000);
  ctx.lineTo(97.000000,226.000000);
  ctx.lineTo(104.000000,214.000000);
  ctx.lineTo(112.000000,209.000000);
  ctx.lineTo(104.000000,208.000000);
  ctx.lineTo(113.000000,202.000000);
  ctx.lineTo(126.000000,200.000000);
  ctx.lineTo(139.000000,207.000000);
  ctx.lineTo(132.000000,198.000000);
  ctx.lineTo(142.000000,203.000000);
  ctx.lineTo(134.000000,192.000000);
  ctx.lineTo(142.000000,195.000000);
  ctx.lineTo(134.000000,187.000000);
  ctx.lineTo(140.000000,185.000000);
  ctx.lineTo(130.000000,181.000000);
  ctx.lineTo(136.000000,177.000000);
  ctx.lineTo(126.000000,177.000000);
  ctx.lineTo(125.000000,171.000000);
  ctx.lineTo(116.000000,180.000000);
  ctx.lineTo(116.000000,172.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(74.000000,220.000000);
  ctx.lineTo(67.000000,230.000000);
  ctx.lineTo(67.000000,221.000000);
  ctx.lineTo(59.000000,235.000000);
  ctx.lineTo(63.000000,233.000000);
  ctx.lineTo(60.000000,248.000000);
  ctx.lineTo(70.000000,232.000000);
  ctx.lineTo(65.000000,249.000000);
  ctx.lineTo(71.000000,243.000000);
  ctx.lineTo(67.000000,256.000000);
  ctx.lineTo(73.000000,250.000000);
  ctx.lineTo(69.000000,262.000000);
  ctx.lineTo(73.000000,259.000000);
  ctx.lineTo(71.000000,267.000000);
  ctx.lineTo(76.000000,262.000000);
  ctx.lineTo(72.000000,271.000000);
  ctx.lineTo(78.000000,270.000000);
  ctx.lineTo(76.000000,275.000000);
  ctx.lineTo(82.000000,274.000000);
  ctx.lineTo(78.000000,290.000000);
  ctx.lineTo(86.000000,279.000000);
  ctx.lineTo(86.000000,289.000000);
  ctx.lineTo(92.000000,274.000000);
  ctx.lineTo(88.000000,275.000000);
  ctx.lineTo(87.000000,264.000000);
  ctx.lineTo(82.000000,270.000000);
  ctx.lineTo(82.000000,258.000000);
  ctx.lineTo(77.000000,257.000000);
  ctx.lineTo(78.000000,247.000000);
  ctx.lineTo(73.000000,246.000000);
  ctx.lineTo(77.000000,233.000000);
  ctx.lineTo(72.000000,236.000000);
  ctx.lineTo(74.000000,220.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(133.000000,230.000000);
  ctx.lineTo(147.000000,242.000000);
  ctx.lineTo(148.000000,250.000000);
  ctx.lineTo(145.000000,254.000000);
  ctx.lineTo(138.000000,247.000000);
  ctx.lineTo(129.000000,246.000000);
  ctx.lineTo(142.000000,245.000000);
  ctx.lineTo(138.000000,241.000000);
  ctx.lineTo(128.000000,237.000000);
  ctx.lineTo(137.000000,238.000000);
  ctx.lineTo(133.000000,230.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(133.000000,261.000000);
  ctx.lineTo(125.000000,261.000000);
  ctx.lineTo(116.000000,263.000000);
  ctx.lineTo(111.000000,267.000000);
  ctx.lineTo(125.000000,265.000000);
  ctx.lineTo(133.000000,261.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(121.000000,271.000000);
  ctx.lineTo(109.000000,273.000000);
  ctx.lineTo(103.000000,279.000000);
  ctx.lineTo(99.000000,305.000000);
  ctx.lineTo(92.000000,316.000000);
  ctx.lineTo(85.000000,327.000000);
  ctx.lineTo(83.000000,335.000000);
  ctx.lineTo(89.000000,340.000000);
  ctx.lineTo(97.000000,341.000000);
  ctx.lineTo(94.000000,336.000000);
  ctx.lineTo(101.000000,336.000000);
  ctx.lineTo(96.000000,331.000000);
  ctx.lineTo(103.000000,330.000000);
  ctx.lineTo(97.000000,327.000000);
  ctx.lineTo(108.000000,325.000000);
  ctx.lineTo(99.000000,322.000000);
  ctx.lineTo(109.000000,321.000000);
  ctx.lineTo(100.000000,318.000000);
  ctx.lineTo(110.000000,317.000000);
  ctx.lineTo(105.000000,314.000000);
  ctx.lineTo(110.000000,312.000000);
  ctx.lineTo(107.000000,310.000000);
  ctx.lineTo(113.000000,308.000000);
  ctx.lineTo(105.000000,306.000000);
  ctx.lineTo(114.000000,303.000000);
  ctx.lineTo(105.000000,301.000000);
  ctx.lineTo(115.000000,298.000000);
  ctx.lineTo(107.000000,295.000000);
  ctx.lineTo(115.000000,294.000000);
  ctx.lineTo(108.000000,293.000000);
  ctx.lineTo(117.000000,291.000000);
  ctx.lineTo(109.000000,289.000000);
  ctx.lineTo(117.000000,286.000000);
  ctx.lineTo(109.000000,286.000000);
  ctx.lineTo(118.000000,283.000000);
  ctx.lineTo(112.000000,281.000000);
  ctx.lineTo(118.000000,279.000000);
  ctx.lineTo(114.000000,278.000000);
  ctx.lineTo(119.000000,276.000000);
  ctx.lineTo(115.000000,274.000000);
  ctx.lineTo(121.000000,271.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(79.000000,364.000000);
  ctx.lineTo(74.000000,359.000000);
  ctx.lineTo(74.000000,353.000000);
  ctx.lineTo(76.000000,347.000000);
  ctx.lineTo(80.000000,351.000000);
  ctx.lineTo(83.000000,356.000000);
  ctx.lineTo(82.000000,360.000000);
  ctx.lineTo(79.000000,364.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(91.000000,363.000000);
  ctx.lineTo(93.000000,356.000000);
  ctx.lineTo(97.000000,353.000000);
  ctx.lineTo(103.000000,355.000000);
  ctx.lineTo(105.000000,360.000000);
  ctx.lineTo(103.000000,366.000000);
  ctx.lineTo(99.000000,371.000000);
  ctx.lineTo(94.000000,368.000000);
  ctx.lineTo(91.000000,363.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(110.000000,355.000000);
  ctx.lineTo(114.000000,353.000000);
  ctx.lineTo(118.000000,357.000000);
  ctx.lineTo(117.000000,363.000000);
  ctx.lineTo(113.000000,369.000000);
  ctx.lineTo(111.000000,362.000000);
  ctx.lineTo(110.000000,355.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(126.000000,354.000000);
  ctx.lineTo(123.000000,358.000000);
  ctx.lineTo(124.000000,367.000000);
  ctx.lineTo(126.000000,369.000000);
  ctx.lineTo(129.000000,361.000000);
  ctx.lineTo(129.000000,357.000000);
  ctx.lineTo(126.000000,354.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(30.000000,154.000000);
  ctx.lineTo(24.000000,166.000000);
  ctx.lineTo(20.000000,182.000000);
  ctx.lineTo(23.000000,194.000000);
  ctx.lineTo(29.000000,208.000000);
  ctx.lineTo(37.000000,218.000000);
  ctx.lineTo(41.000000,210.000000);
  ctx.lineTo(41.000000,223.000000);
  ctx.lineTo(46.000000,214.000000);
  ctx.lineTo(46.000000,227.000000);
  ctx.lineTo(52.000000,216.000000);
  ctx.lineTo(52.000000,227.000000);
  ctx.lineTo(61.000000,216.000000);
  ctx.lineTo(59.000000,225.000000);
  ctx.lineTo(68.000000,213.000000);
  ctx.lineTo(73.000000,219.000000);
  ctx.lineTo(70.000000,207.000000);
  ctx.lineTo(77.000000,212.000000);
  ctx.lineTo(69.000000,200.000000);
  ctx.lineTo(77.000000,202.000000);
  ctx.lineTo(70.000000,194.000000);
  ctx.lineTo(78.000000,197.000000);
  ctx.lineTo(68.000000,187.000000);
  ctx.lineTo(76.000000,182.000000);
  ctx.lineTo(64.000000,182.000000);
  ctx.lineTo(58.000000,175.000000);
  ctx.lineTo(58.000000,185.000000);
  ctx.lineTo(53.000000,177.000000);
  ctx.lineTo(50.000000,186.000000);
  ctx.lineTo(46.000000,171.000000);
  ctx.lineTo(44.000000,182.000000);
  ctx.lineTo(39.000000,167.000000);
  ctx.lineTo(36.000000,172.000000);
  ctx.lineTo(36.000000,162.000000);
  ctx.lineTo(30.000000,166.000000);
  ctx.lineTo(30.000000,154.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(44.000000,130.000000);
  ctx.lineTo(41.000000,137.000000);
  ctx.lineTo(45.000000,136.000000);
  ctx.lineTo(43.000000,150.000000);
  ctx.lineTo(48.000000,142.000000);
  ctx.lineTo(48.000000,157.000000);
  ctx.lineTo(53.000000,150.000000);
  ctx.lineTo(52.000000,164.000000);
  ctx.lineTo(60.000000,156.000000);
  ctx.lineTo(61.000000,169.000000);
  ctx.lineTo(64.000000,165.000000);
  ctx.lineTo(66.000000,175.000000);
  ctx.lineTo(70.000000,167.000000);
  ctx.lineTo(74.000000,176.000000);
  ctx.lineTo(77.000000,168.000000);
  ctx.lineTo(80.000000,183.000000);
  ctx.lineTo(85.000000,172.000000);
  ctx.lineTo(90.000000,182.000000);
  ctx.lineTo(93.000000,174.000000);
  ctx.lineTo(98.000000,181.000000);
  ctx.lineTo(99.000000,173.000000);
  ctx.lineTo(104.000000,175.000000);
  ctx.lineTo(105.000000,169.000000);
  ctx.lineTo(114.000000,168.000000);
  ctx.lineTo(102.000000,163.000000);
  ctx.lineTo(95.000000,157.000000);
  ctx.lineTo(94.000000,166.000000);
  ctx.lineTo(90.000000,154.000000);
  ctx.lineTo(87.000000,162.000000);
  ctx.lineTo(82.000000,149.000000);
  ctx.lineTo(75.000000,159.000000);
  ctx.lineTo(72.000000,148.000000);
  ctx.lineTo(68.000000,155.000000);
  ctx.lineTo(67.000000,143.000000);
  ctx.lineTo(62.000000,148.000000);
  ctx.lineTo(62.000000,138.000000);
  ctx.lineTo(58.000000,145.000000);
  ctx.lineTo(56.000000,133.000000);
  ctx.lineTo(52.000000,142.000000);
  ctx.lineTo(52.000000,128.000000);
  ctx.lineTo(49.000000,134.000000);
  ctx.lineTo(47.000000,125.000000);
  ctx.lineTo(44.000000,130.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(13.000000,216.000000);
  ctx.lineTo(19.000000,219.000000);
  ctx.lineTo(36.000000,231.000000);
  ctx.lineTo(22.000000,223.000000);
  ctx.lineTo(16.000000,222.000000);
  ctx.lineTo(22.000000,227.000000);
  ctx.lineTo(12.000000,224.000000);
  ctx.lineTo(13.000000,220.000000);
  ctx.lineTo(16.000000,220.000000);
  ctx.lineTo(13.000000,216.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(10.000000,231.000000);
  ctx.lineTo(14.000000,236.000000);
  ctx.lineTo(25.000000,239.000000);
  ctx.lineTo(27.000000,237.000000);
  ctx.lineTo(19.000000,234.000000);
  ctx.lineTo(10.000000,231.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(9.000000,245.000000);
  ctx.lineTo(14.000000,242.000000);
  ctx.lineTo(25.000000,245.000000);
  ctx.lineTo(13.000000,245.000000);
  ctx.lineTo(9.000000,245.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(33.000000,255.000000);
  ctx.lineTo(26.000000,253.000000);
  ctx.lineTo(18.000000,254.000000);
  ctx.lineTo(25.000000,256.000000);
  ctx.lineTo(18.000000,258.000000);
  ctx.lineTo(27.000000,260.000000);
  ctx.lineTo(18.000000,263.000000);
  ctx.lineTo(27.000000,265.000000);
  ctx.lineTo(19.000000,267.000000);
  ctx.lineTo(29.000000,270.000000);
  ctx.lineTo(21.000000,272.000000);
  ctx.lineTo(29.000000,276.000000);
  ctx.lineTo(21.000000,278.000000);
  ctx.lineTo(30.000000,281.000000);
  ctx.lineTo(22.000000,283.000000);
  ctx.lineTo(31.000000,287.000000);
  ctx.lineTo(24.000000,288.000000);
  ctx.lineTo(32.000000,292.000000);
  ctx.lineTo(23.000000,293.000000);
  ctx.lineTo(34.000000,298.000000);
  ctx.lineTo(26.000000,299.000000);
  ctx.lineTo(37.000000,303.000000);
  ctx.lineTo(32.000000,305.000000);
  ctx.lineTo(39.000000,309.000000);
  ctx.lineTo(33.000000,309.000000);
  ctx.lineTo(39.000000,314.000000);
  ctx.lineTo(34.000000,314.000000);
  ctx.lineTo(40.000000,318.000000);
  ctx.lineTo(34.000000,317.000000);
  ctx.lineTo(40.000000,321.000000);
  ctx.lineTo(34.000000,321.000000);
  ctx.lineTo(41.000000,326.000000);
  ctx.lineTo(33.000000,326.000000);
  ctx.lineTo(40.000000,330.000000);
  ctx.lineTo(33.000000,332.000000);
  ctx.lineTo(39.000000,333.000000);
  ctx.lineTo(33.000000,337.000000);
  ctx.lineTo(42.000000,337.000000);
  ctx.lineTo(54.000000,341.000000);
  ctx.lineTo(49.000000,337.000000);
  ctx.lineTo(52.000000,335.000000);
  ctx.lineTo(47.000000,330.000000);
  ctx.lineTo(50.000000,330.000000);
  ctx.lineTo(45.000000,325.000000);
  ctx.lineTo(49.000000,325.000000);
  ctx.lineTo(45.000000,321.000000);
  ctx.lineTo(48.000000,321.000000);
  ctx.lineTo(45.000000,316.000000);
  ctx.lineTo(46.000000,306.000000);
  ctx.lineTo(45.000000,286.000000);
  ctx.lineTo(43.000000,274.000000);
  ctx.lineTo(36.000000,261.000000);
  ctx.lineTo(33.000000,255.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(7.000000,358.000000);
  ctx.lineTo(9.000000,351.000000);
  ctx.lineTo(14.000000,351.000000);
  ctx.lineTo(17.000000,359.000000);
  ctx.lineTo(11.000000,364.000000);
  ctx.lineTo(7.000000,358.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(44.000000,354.000000);
  ctx.lineTo(49.000000,351.000000);
  ctx.lineTo(52.000000,355.000000);
  ctx.lineTo(49.000000,361.000000);
  ctx.lineTo(44.000000,354.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(32.000000,357.000000);
  ctx.lineTo(37.000000,353.000000);
  ctx.lineTo(40.000000,358.000000);
  ctx.lineTo(36.000000,361.000000);
  ctx.lineTo(32.000000,357.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(139.000000,334.000000);
  ctx.lineTo(145.000000,330.000000);
  ctx.lineTo(154.000000,330.000000);
  ctx.lineTo(158.000000,334.000000);
  ctx.lineTo(154.000000,341.000000);
  ctx.lineTo(152.000000,348.000000);
  ctx.lineTo(145.000000,350.000000);
  ctx.lineTo(149.000000,340.000000);
  ctx.lineTo(147.000000,336.000000);
  ctx.lineTo(141.000000,339.000000);
  ctx.lineTo(139.000000,345.000000);
  ctx.lineTo(136.000000,342.000000);
  ctx.lineTo(136.000000,339.000000);
  ctx.lineTo(139.000000,334.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(208.000000,259.000000);
  ctx.lineTo(215.000000,259.000000);
  ctx.lineTo(212.000000,255.000000);
  ctx.lineTo(220.000000,259.000000);
  ctx.lineTo(224.000000,263.000000);
  ctx.lineTo(225.000000,274.000000);
  ctx.lineTo(224.000000,283.000000);
  ctx.lineTo(220.000000,292.000000);
  ctx.lineTo(208.000000,300.000000);
  ctx.lineTo(206.000000,308.000000);
  ctx.lineTo(203.000000,304.000000);
  ctx.lineTo(199.000000,315.000000);
  ctx.lineTo(197.000000,309.000000);
  ctx.lineTo(195.000000,318.000000);
  ctx.lineTo(193.000000,313.000000);
  ctx.lineTo(190.000000,322.000000);
  ctx.lineTo(190.000000,316.000000);
  ctx.lineTo(185.000000,325.000000);
  ctx.lineTo(182.000000,318.000000);
  ctx.lineTo(180.000000,325.000000);
  ctx.lineTo(172.000000,321.000000);
  ctx.lineTo(178.000000,320.000000);
  ctx.lineTo(176.000000,313.000000);
  ctx.lineTo(186.000000,312.000000);
  ctx.lineTo(180.000000,307.000000);
  ctx.lineTo(188.000000,307.000000);
  ctx.lineTo(184.000000,303.000000);
  ctx.lineTo(191.000000,302.000000);
  ctx.lineTo(186.000000,299.000000);
  ctx.lineTo(195.000000,294.000000);
  ctx.lineTo(187.000000,290.000000);
  ctx.lineTo(197.000000,288.000000);
  ctx.lineTo(192.000000,286.000000);
  ctx.lineTo(201.000000,283.000000);
  ctx.lineTo(194.000000,280.000000);
  ctx.lineTo(203.000000,277.000000);
  ctx.lineTo(198.000000,275.000000);
  ctx.lineTo(207.000000,271.000000);
  ctx.lineTo(200.000000,269.000000);
  ctx.lineTo(209.000000,265.000000);
  ctx.lineTo(204.000000,265.000000);
  ctx.lineTo(212.000000,262.000000);
  ctx.lineTo(208.000000,259.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(106.000000,126.000000);
  ctx.lineTo(106.000000,131.000000);
  ctx.lineTo(109.000000,132.000000);
  ctx.lineTo(111.000000,134.000000);
  ctx.lineTo(115.000000,132.000000);
  ctx.lineTo(115.000000,135.000000);
  ctx.lineTo(119.000000,133.000000);
  ctx.lineTo(118.000000,137.000000);
  ctx.lineTo(123.000000,137.000000);
  ctx.lineTo(128.000000,137.000000);
  ctx.lineTo(133.000000,134.000000);
  ctx.lineTo(136.000000,130.000000);
  ctx.lineTo(136.000000,127.000000);
  ctx.lineTo(132.000000,124.000000);
  ctx.lineTo(118.000000,128.000000);
  ctx.lineTo(112.000000,128.000000);
  ctx.lineTo(106.000000,126.000000);
  ctx.lineTo(106.000000,126.000000);
  ctx.lineTo(106.000000,126.000000);
  ctx.lineTo(106.000000,126.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(107.000000,114.000000);
  ctx.lineTo(101.000000,110.000000);
  ctx.lineTo(98.000000,102.000000);
  ctx.lineTo(105.000000,97.000000);
  ctx.lineTo(111.000000,98.000000);
  ctx.lineTo(119.000000,102.000000);
  ctx.lineTo(121.000000,108.000000);
  ctx.lineTo(118.000000,112.000000);
  ctx.lineTo(113.000000,115.000000);
  ctx.lineTo(107.000000,114.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(148.000000,106.000000);
  ctx.lineTo(145.000000,110.000000);
  ctx.lineTo(146.000000,116.000000);
  ctx.lineTo(150.000000,118.000000);
  ctx.lineTo(152.000000,111.000000);
  ctx.lineTo(151.000000,107.000000);
  ctx.lineTo(148.000000,106.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(80.000000,55.000000);
  ctx.lineTo(70.000000,52.000000);
  ctx.lineTo(75.000000,58.000000);
  ctx.lineTo(63.000000,57.000000);
  ctx.lineTo(72.000000,61.000000);
  ctx.lineTo(57.000000,61.000000);
  ctx.lineTo(67.000000,66.000000);
  ctx.lineTo(57.000000,67.000000);
  ctx.lineTo(62.000000,69.000000);
  ctx.lineTo(54.000000,71.000000);
  ctx.lineTo(61.000000,73.000000);
  ctx.lineTo(54.000000,77.000000);
  ctx.lineTo(63.000000,78.000000);
  ctx.lineTo(53.000000,85.000000);
  ctx.lineTo(60.000000,84.000000);
  ctx.lineTo(56.000000,90.000000);
  ctx.lineTo(69.000000,84.000000);
  ctx.lineTo(63.000000,82.000000);
  ctx.lineTo(75.000000,76.000000);
  ctx.lineTo(70.000000,75.000000);
  ctx.lineTo(77.000000,72.000000);
  ctx.lineTo(72.000000,71.000000);
  ctx.lineTo(78.000000,69.000000);
  ctx.lineTo(72.000000,66.000000);
  ctx.lineTo(81.000000,67.000000);
  ctx.lineTo(78.000000,64.000000);
  ctx.lineTo(82.000000,63.000000);
  ctx.lineTo(80.000000,60.000000);
  ctx.lineTo(86.000000,62.000000);
  ctx.lineTo(80.000000,55.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(87.000000,56.000000);
  ctx.lineTo(91.000000,52.000000);
  ctx.lineTo(96.000000,50.000000);
  ctx.lineTo(102.000000,56.000000);
  ctx.lineTo(98.000000,56.000000);
  ctx.lineTo(92.000000,60.000000);
  ctx.lineTo(87.000000,56.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(85.000000,68.000000);
  ctx.lineTo(89.000000,73.000000);
  ctx.lineTo(98.000000,76.000000);
  ctx.lineTo(106.000000,74.000000);
  ctx.lineTo(96.000000,73.000000);
  ctx.lineTo(91.000000,70.000000);
  ctx.lineTo(85.000000,68.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(115.000000,57.000000);
  ctx.lineTo(114.000000,64.000000);
  ctx.lineTo(111.000000,64.000000);
  ctx.lineTo(115.000000,75.000000);
  ctx.lineTo(122.000000,81.000000);
  ctx.lineTo(122.000000,74.000000);
  ctx.lineTo(126.000000,79.000000);
  ctx.lineTo(126.000000,74.000000);
  ctx.lineTo(131.000000,78.000000);
  ctx.lineTo(130.000000,72.000000);
  ctx.lineTo(133.000000,77.000000);
  ctx.lineTo(131.000000,68.000000);
  ctx.lineTo(126.000000,61.000000);
  ctx.lineTo(119.000000,57.000000);
  ctx.lineTo(115.000000,57.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(145.000000,48.000000);
  ctx.lineTo(143.000000,53.000000);
  ctx.lineTo(147.000000,59.000000);
  ctx.lineTo(151.000000,59.000000);
  ctx.lineTo(150.000000,55.000000);
  ctx.lineTo(145.000000,48.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(26.000000,22.000000);
  ctx.lineTo(34.000000,15.000000);
  ctx.lineTo(43.000000,10.000000);
  ctx.lineTo(52.000000,10.000000);
  ctx.lineTo(59.000000,16.000000);
  ctx.lineTo(47.000000,15.000000);
  ctx.lineTo(32.000000,22.000000);
  ctx.lineTo(26.000000,22.000000);
ctx.fill();




ctx.fillStyle='#ffe5b2';
ctx.beginPath();
ctx.moveTo(160.000000,19.000000);
  ctx.lineTo(152.000000,26.000000);
  ctx.lineTo(149.000000,34.000000);
  ctx.lineTo(154.000000,33.000000);
  ctx.lineTo(152.000000,30.000000);
  ctx.lineTo(157.000000,30.000000);
  ctx.lineTo(155.000000,26.000000);
  ctx.lineTo(158.000000,27.000000);
  ctx.lineTo(157.000000,23.000000);
  ctx.lineTo(161.000000,23.000000);
  ctx.lineTo(160.000000,19.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(98.000000,117.000000);
  ctx.lineTo(105.000000,122.000000);
  ctx.lineTo(109.000000,122.000000);
  ctx.lineTo(105.000000,117.000000);
  ctx.lineTo(113.000000,120.000000);
  ctx.lineTo(121.000000,120.000000);
  ctx.lineTo(130.000000,112.000000);
  ctx.lineTo(128.000000,108.000000);
  ctx.lineTo(123.000000,103.000000);
  ctx.lineTo(123.000000,99.000000);
  ctx.lineTo(128.000000,101.000000);
  ctx.lineTo(132.000000,106.000000);
  ctx.lineTo(135.000000,109.000000);
  ctx.lineTo(142.000000,105.000000);
  ctx.lineTo(142.000000,101.000000);
  ctx.lineTo(145.000000,101.000000);
  ctx.lineTo(145.000000,91.000000);
  ctx.lineTo(148.000000,101.000000);
  ctx.lineTo(145.000000,105.000000);
  ctx.lineTo(136.000000,112.000000);
  ctx.lineTo(135.000000,116.000000);
  ctx.lineTo(143.000000,124.000000);
  ctx.lineTo(148.000000,120.000000);
  ctx.lineTo(150.000000,122.000000);
  ctx.lineTo(142.000000,128.000000);
  ctx.lineTo(133.000000,122.000000);
  ctx.lineTo(121.000000,125.000000);
  ctx.lineTo(112.000000,126.000000);
  ctx.lineTo(103.000000,125.000000);
  ctx.lineTo(100.000000,129.000000);
  ctx.lineTo(96.000000,124.000000);
  ctx.lineTo(98.000000,117.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(146.000000,118.000000);
  ctx.lineTo(152.000000,118.000000);
  ctx.lineTo(152.000000,115.000000);
  ctx.lineTo(149.000000,115.000000);
  ctx.lineTo(146.000000,118.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(148.000000,112.000000);
  ctx.lineTo(154.000000,111.000000);
  ctx.lineTo(154.000000,109.000000);
  ctx.lineTo(149.000000,109.000000);
  ctx.lineTo(148.000000,112.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(106.000000,112.000000);
  ctx.lineTo(108.000000,115.000000);
  ctx.lineTo(114.000000,116.000000);
  ctx.lineTo(118.000000,114.000000);
  ctx.lineTo(106.000000,112.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(108.000000,108.000000);
  ctx.lineTo(111.000000,110.000000);
  ctx.lineTo(116.000000,110.000000);
  ctx.lineTo(119.000000,108.000000);
  ctx.lineTo(108.000000,108.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(106.000000,104.000000);
  ctx.lineTo(109.000000,105.000000);
  ctx.lineTo(117.000000,106.000000);
  ctx.lineTo(115.000000,104.000000);
  ctx.lineTo(106.000000,104.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(50.000000,25.000000);
  ctx.lineTo(41.000000,26.000000);
  ctx.lineTo(34.000000,33.000000);
  ctx.lineTo(39.000000,43.000000);
  ctx.lineTo(49.000000,58.000000);
  ctx.lineTo(36.000000,51.000000);
  ctx.lineTo(47.000000,68.000000);
  ctx.lineTo(55.000000,69.000000);
  ctx.lineTo(54.000000,59.000000);
  ctx.lineTo(61.000000,57.000000);
  ctx.lineTo(74.000000,46.000000);
  ctx.lineTo(60.000000,52.000000);
  ctx.lineTo(67.000000,42.000000);
  ctx.lineTo(57.000000,48.000000);
  ctx.lineTo(61.000000,40.000000);
  ctx.lineTo(54.000000,45.000000);
  ctx.lineTo(60.000000,36.000000);
  ctx.lineTo(59.000000,29.000000);
  ctx.lineTo(48.000000,38.000000);
  ctx.lineTo(52.000000,30.000000);
  ctx.lineTo(47.000000,32.000000);
  ctx.lineTo(50.000000,25.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(147.000000,34.000000);
  ctx.lineTo(152.000000,41.000000);
  ctx.lineTo(155.000000,49.000000);
  ctx.lineTo(161.000000,53.000000);
  ctx.lineTo(157.000000,47.000000);
  ctx.lineTo(164.000000,47.000000);
  ctx.lineTo(158.000000,43.000000);
  ctx.lineTo(168.000000,44.000000);
  ctx.lineTo(159.000000,40.000000);
  ctx.lineTo(164.000000,37.000000);
  ctx.lineTo(169.000000,37.000000);
  ctx.lineTo(164.000000,33.000000);
  ctx.lineTo(169.000000,34.000000);
  ctx.lineTo(165.000000,28.000000);
  ctx.lineTo(170.000000,30.000000);
  ctx.lineTo(170.000000,25.000000);
  ctx.lineTo(173.000000,29.000000);
  ctx.lineTo(175.000000,27.000000);
  ctx.lineTo(176.000000,32.000000);
  ctx.lineTo(173.000000,36.000000);
  ctx.lineTo(175.000000,39.000000);
  ctx.lineTo(172.000000,42.000000);
  ctx.lineTo(172.000000,46.000000);
  ctx.lineTo(168.000000,49.000000);
  ctx.lineTo(170.000000,55.000000);
  ctx.lineTo(162.000000,57.000000);
  ctx.lineTo(158.000000,63.000000);
  ctx.lineTo(155.000000,58.000000);
  ctx.lineTo(153.000000,50.000000);
  ctx.lineTo(149.000000,46.000000);
  ctx.lineTo(147.000000,34.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(155.000000,71.000000);
  ctx.lineTo(159.000000,80.000000);
  ctx.lineTo(157.000000,93.000000);
  ctx.lineTo(157.000000,102.000000);
  ctx.lineTo(155.000000,108.000000);
  ctx.lineTo(150.000000,101.000000);
  ctx.lineTo(149.000000,93.000000);
  ctx.lineTo(154.000000,101.000000);
  ctx.lineTo(152.000000,91.000000);
  ctx.lineTo(151.000000,83.000000);
  ctx.lineTo(155.000000,79.000000);
  ctx.lineTo(155.000000,71.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(112.000000,78.000000);
  ctx.lineTo(115.000000,81.000000);
  ctx.lineTo(114.000000,91.000000);
  ctx.lineTo(112.000000,87.000000);
  ctx.lineTo(113.000000,82.000000);
  ctx.lineTo(112.000000,78.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(78.000000,28.000000);
  ctx.lineTo(64.000000,17.000000);
  ctx.lineTo(58.000000,11.000000);
  ctx.lineTo(47.000000,9.000000);
  ctx.lineTo(36.000000,10.000000);
  ctx.lineTo(28.000000,16.000000);
  ctx.lineTo(21.000000,26.000000);
  ctx.lineTo(18.000000,41.000000);
  ctx.lineTo(20.000000,51.000000);
  ctx.lineTo(23.000000,61.000000);
  ctx.lineTo(33.000000,65.000000);
  ctx.lineTo(28.000000,68.000000);
  ctx.lineTo(37.000000,74.000000);
  ctx.lineTo(36.000000,81.000000);
  ctx.lineTo(43.000000,87.000000);
  ctx.lineTo(48.000000,90.000000);
  ctx.lineTo(43.000000,100.000000);
  ctx.lineTo(40.000000,98.000000);
  ctx.lineTo(39.000000,90.000000);
  ctx.lineTo(31.000000,80.000000);
  ctx.lineTo(30.000000,72.000000);
  ctx.lineTo(22.000000,71.000000);
  ctx.lineTo(17.000000,61.000000);
  ctx.lineTo(14.000000,46.000000);
  ctx.lineTo(16.000000,28.000000);
  ctx.lineTo(23.000000,17.000000);
  ctx.lineTo(33.000000,9.000000);
  ctx.lineTo(45.000000,6.000000);
  ctx.lineTo(54.000000,6.000000);
  ctx.lineTo(65.000000,12.000000);
  ctx.lineTo(78.000000,28.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(67.000000,18.000000);
  ctx.lineTo(76.000000,9.000000);
  ctx.lineTo(87.000000,5.000000);
  ctx.lineTo(101.000000,2.000000);
  ctx.lineTo(118.000000,3.000000);
  ctx.lineTo(135.000000,8.000000);
  ctx.lineTo(149.000000,20.000000);
  ctx.lineTo(149.000000,26.000000);
  ctx.lineTo(144.000000,19.000000);
  ctx.lineTo(132.000000,12.000000);
  ctx.lineTo(121.000000,9.000000);
  ctx.lineTo(105.000000,7.000000);
  ctx.lineTo(89.000000,8.000000);
  ctx.lineTo(76.000000,14.000000);
  ctx.lineTo(70.000000,20.000000);
  ctx.lineTo(67.000000,18.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(56.000000,98.000000);
  ctx.lineTo(48.000000,106.000000);
  ctx.lineTo(56.000000,103.000000);
  ctx.lineTo(47.000000,112.000000);
  ctx.lineTo(56.000000,110.000000);
  ctx.lineTo(52.000000,115.000000);
  ctx.lineTo(57.000000,113.000000);
  ctx.lineTo(52.000000,121.000000);
  ctx.lineTo(62.000000,115.000000);
  ctx.lineTo(58.000000,123.000000);
  ctx.lineTo(65.000000,119.000000);
  ctx.lineTo(63.000000,125.000000);
  ctx.lineTo(69.000000,121.000000);
  ctx.lineTo(68.000000,127.000000);
  ctx.lineTo(74.000000,125.000000);
  ctx.lineTo(74.000000,129.000000);
  ctx.lineTo(79.000000,128.000000);
  ctx.lineTo(83.000000,132.000000);
  ctx.lineTo(94.000000,135.000000);
  ctx.lineTo(93.000000,129.000000);
  ctx.lineTo(85.000000,127.000000);
  ctx.lineTo(81.000000,122.000000);
  ctx.lineTo(76.000000,126.000000);
  ctx.lineTo(75.000000,121.000000);
  ctx.lineTo(71.000000,124.000000);
  ctx.lineTo(71.000000,117.000000);
  ctx.lineTo(66.000000,121.000000);
  ctx.lineTo(66.000000,117.000000);
  ctx.lineTo(62.000000,117.000000);
  ctx.lineTo(64.000000,112.000000);
  ctx.lineTo(60.000000,113.000000);
  ctx.lineTo(60.000000,110.000000);
  ctx.lineTo(57.000000,111.000000);
  ctx.lineTo(61.000000,105.000000);
  ctx.lineTo(57.000000,107.000000);
  ctx.lineTo(60.000000,101.000000);
  ctx.lineTo(55.000000,102.000000);
  ctx.lineTo(56.000000,98.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(101.000000,132.000000);
  ctx.lineTo(103.000000,138.000000);
  ctx.lineTo(106.000000,134.000000);
  ctx.lineTo(106.000000,139.000000);
  ctx.lineTo(112.000000,136.000000);
  ctx.lineTo(111.000000,142.000000);
  ctx.lineTo(115.000000,139.000000);
  ctx.lineTo(114.000000,143.000000);
  ctx.lineTo(119.000000,142.000000);
  ctx.lineTo(125.000000,145.000000);
  ctx.lineTo(131.000000,142.000000);
  ctx.lineTo(135.000000,138.000000);
  ctx.lineTo(140.000000,134.000000);
  ctx.lineTo(140.000000,129.000000);
  ctx.lineTo(143.000000,135.000000);
  ctx.lineTo(145.000000,149.000000);
  ctx.lineTo(150.000000,171.000000);
  ctx.lineTo(149.000000,184.000000);
  ctx.lineTo(145.000000,165.000000);
  ctx.lineTo(141.000000,150.000000);
  ctx.lineTo(136.000000,147.000000);
  ctx.lineTo(132.000000,151.000000);
  ctx.lineTo(131.000000,149.000000);
  ctx.lineTo(126.000000,152.000000);
  ctx.lineTo(125.000000,150.000000);
  ctx.lineTo(121.000000,152.000000);
  ctx.lineTo(117.000000,148.000000);
  ctx.lineTo(111.000000,152.000000);
  ctx.lineTo(110.000000,148.000000);
  ctx.lineTo(105.000000,149.000000);
  ctx.lineTo(104.000000,145.000000);
  ctx.lineTo(98.000000,150.000000);
  ctx.lineTo(96.000000,138.000000);
  ctx.lineTo(94.000000,132.000000);
  ctx.lineTo(94.000000,130.000000);
  ctx.lineTo(98.000000,132.000000);
  ctx.lineTo(101.000000,132.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(41.000000,94.000000);
  ctx.lineTo(32.000000,110.000000);
  ctx.lineTo(23.000000,132.000000);
  ctx.lineTo(12.000000,163.000000);
  ctx.lineTo(6.000000,190.000000);
  ctx.lineTo(7.000000,217.000000);
  ctx.lineTo(5.000000,236.000000);
  ctx.lineTo(3.000000,247.000000);
  ctx.lineTo(9.000000,230.000000);
  ctx.lineTo(12.000000,211.000000);
  ctx.lineTo(12.000000,185.000000);
  ctx.lineTo(18.000000,160.000000);
  ctx.lineTo(26.000000,134.000000);
  ctx.lineTo(35.000000,110.000000);
  ctx.lineTo(43.000000,99.000000);
  ctx.lineTo(41.000000,94.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(32.000000,246.000000);
  ctx.lineTo(41.000000,250.000000);
  ctx.lineTo(50.000000,257.000000);
  ctx.lineTo(52.000000,267.000000);
  ctx.lineTo(53.000000,295.000000);
  ctx.lineTo(53.000000,323.000000);
  ctx.lineTo(59.000000,350.000000);
  ctx.lineTo(54.000000,363.000000);
  ctx.lineTo(51.000000,365.000000);
  ctx.lineTo(44.000000,366.000000);
  ctx.lineTo(42.000000,360.000000);
  ctx.lineTo(40.000000,372.000000);
  ctx.lineTo(54.000000,372.000000);
  ctx.lineTo(59.000000,366.000000);
  ctx.lineTo(62.000000,353.000000);
  ctx.lineTo(71.000000,352.000000);
  ctx.lineTo(75.000000,335.000000);
  ctx.lineTo(73.000000,330.000000);
  ctx.lineTo(66.000000,318.000000);
  ctx.lineTo(68.000000,302.000000);
  ctx.lineTo(64.000000,294.000000);
  ctx.lineTo(67.000000,288.000000);
  ctx.lineTo(63.000000,286.000000);
  ctx.lineTo(63.000000,279.000000);
  ctx.lineTo(59.000000,275.000000);
  ctx.lineTo(58.000000,267.000000);
  ctx.lineTo(56.000000,262.000000);
  ctx.lineTo(50.000000,247.000000);
  ctx.lineTo(42.000000,235.000000);
  ctx.lineTo(44.000000,246.000000);
  ctx.lineTo(32.000000,236.000000);
  ctx.lineTo(35.000000,244.000000);
  ctx.lineTo(32.000000,246.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(134.000000,324.000000);
  ctx.lineTo(146.000000,320.000000);
  ctx.lineTo(159.000000,322.000000);
  ctx.lineTo(173.000000,327.000000);
  ctx.lineTo(179.000000,337.000000);
  ctx.lineTo(179.000000,349.000000);
  ctx.lineTo(172.000000,355.000000);
  ctx.lineTo(158.000000,357.000000);
  ctx.lineTo(170.000000,350.000000);
  ctx.lineTo(174.000000,343.000000);
  ctx.lineTo(170.000000,333.000000);
  ctx.lineTo(163.000000,328.000000);
  ctx.lineTo(152.000000,326.000000);
  ctx.lineTo(134.000000,329.000000);
  ctx.lineTo(134.000000,324.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(173.000000,339.000000);
  ctx.lineTo(183.000000,334.000000);
  ctx.lineTo(184.000000,338.000000);
  ctx.lineTo(191.000000,329.000000);
  ctx.lineTo(194.000000,332.000000);
  ctx.lineTo(199.000000,323.000000);
  ctx.lineTo(202.000000,325.000000);
  ctx.lineTo(206.000000,318.000000);
  ctx.lineTo(209.000000,320.000000);
  ctx.lineTo(213.000000,309.000000);
  ctx.lineTo(221.000000,303.000000);
  ctx.lineTo(228.000000,296.000000);
  ctx.lineTo(232.000000,289.000000);
  ctx.lineTo(234.000000,279.000000);
  ctx.lineTo(233.000000,269.000000);
  ctx.lineTo(230.000000,262.000000);
  ctx.lineTo(225.000000,256.000000);
  ctx.lineTo(219.000000,253.000000);
  ctx.lineTo(208.000000,252.000000);
  ctx.lineTo(198.000000,252.000000);
  ctx.lineTo(210.000000,249.000000);
  ctx.lineTo(223.000000,250.000000);
  ctx.lineTo(232.000000,257.000000);
  ctx.lineTo(237.000000,265.000000);
  ctx.lineTo(238.000000,277.000000);
  ctx.lineTo(238.000000,291.000000);
  ctx.lineTo(232.000000,305.000000);
  ctx.lineTo(221.000000,323.000000);
  ctx.lineTo(218.000000,335.000000);
  ctx.lineTo(212.000000,342.000000);
  ctx.lineTo(200.000000,349.000000);
  ctx.lineTo(178.000000,348.000000);
  ctx.lineTo(173.000000,339.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(165.000000,296.000000);
  ctx.lineTo(158.000000,301.000000);
  ctx.lineTo(156.000000,310.000000);
  ctx.lineTo(156.000000,323.000000);
  ctx.lineTo(162.000000,324.000000);
  ctx.lineTo(159.000000,318.000000);
  ctx.lineTo(162.000000,308.000000);
  ctx.lineTo(162.000000,304.000000);
  ctx.lineTo(165.000000,296.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(99.000000,252.000000);
  ctx.lineTo(105.000000,244.000000);
  ctx.lineTo(107.000000,234.000000);
  ctx.lineTo(115.000000,228.000000);
  ctx.lineTo(121.000000,228.000000);
  ctx.lineTo(131.000000,235.000000);
  ctx.lineTo(122.000000,233.000000);
  ctx.lineTo(113.000000,235.000000);
  ctx.lineTo(109.000000,246.000000);
  ctx.lineTo(121.000000,239.000000);
  ctx.lineTo(133.000000,243.000000);
  ctx.lineTo(121.000000,243.000000);
  ctx.lineTo(110.000000,251.000000);
  ctx.lineTo(99.000000,252.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(117.000000,252.000000);
  ctx.lineTo(124.000000,247.000000);
  ctx.lineTo(134.000000,249.000000);
  ctx.lineTo(136.000000,253.000000);
  ctx.lineTo(126.000000,252.000000);
  ctx.lineTo(117.000000,252.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(117.000000,218.000000);
  ctx.lineTo(132.000000,224.000000);
  ctx.lineTo(144.000000,233.000000);
  ctx.lineTo(140.000000,225.000000);
  ctx.lineTo(132.000000,219.000000);
  ctx.lineTo(117.000000,218.000000);
  ctx.lineTo(117.000000,218.000000);
  ctx.lineTo(117.000000,218.000000);
  ctx.lineTo(117.000000,218.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(122.000000,212.000000);
  ctx.lineTo(134.000000,214.000000);
  ctx.lineTo(143.000000,221.000000);
  ctx.lineTo(141.000000,213.000000);
  ctx.lineTo(132.000000,210.000000);
  ctx.lineTo(122.000000,212.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(69.000000,352.000000);
  ctx.lineTo(70.000000,363.000000);
  ctx.lineTo(76.000000,373.000000);
  ctx.lineTo(86.000000,378.000000);
  ctx.lineTo(97.000000,379.000000);
  ctx.lineTo(108.000000,379.000000);
  ctx.lineTo(120.000000,377.000000);
  ctx.lineTo(128.000000,378.000000);
  ctx.lineTo(132.000000,373.000000);
  ctx.lineTo(135.000000,361.000000);
  ctx.lineTo(133.000000,358.000000);
  ctx.lineTo(132.000000,366.000000);
  ctx.lineTo(127.000000,375.000000);
  ctx.lineTo(121.000000,374.000000);
  ctx.lineTo(121.000000,362.000000);
  ctx.lineTo(119.000000,367.000000);
  ctx.lineTo(117.000000,374.000000);
  ctx.lineTo(110.000000,376.000000);
  ctx.lineTo(110.000000,362.000000);
  ctx.lineTo(107.000000,357.000000);
  ctx.lineTo(106.000000,371.000000);
  ctx.lineTo(104.000000,375.000000);
  ctx.lineTo(97.000000,376.000000);
  ctx.lineTo(90.000000,375.000000);
  ctx.lineTo(90.000000,368.000000);
  ctx.lineTo(86.000000,362.000000);
  ctx.lineTo(83.000000,364.000000);
  ctx.lineTo(86.000000,369.000000);
  ctx.lineTo(85.000000,373.000000);
  ctx.lineTo(78.000000,370.000000);
  ctx.lineTo(73.000000,362.000000);
  ctx.lineTo(71.000000,351.000000);
  ctx.lineTo(69.000000,352.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(100.000000,360.000000);
  ctx.lineTo(96.000000,363.000000);
  ctx.lineTo(99.000000,369.000000);
  ctx.lineTo(102.000000,364.000000);
  ctx.lineTo(100.000000,360.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(115.000000,360.000000);
  ctx.lineTo(112.000000,363.000000);
  ctx.lineTo(114.000000,369.000000);
  ctx.lineTo(117.000000,364.000000);
  ctx.lineTo(115.000000,360.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(127.000000,362.000000);
  ctx.lineTo(125.000000,364.000000);
  ctx.lineTo(126.000000,369.000000);
  ctx.lineTo(128.000000,365.000000);
  ctx.lineTo(127.000000,362.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(5.000000,255.000000);
  ctx.lineTo(7.000000,276.000000);
  ctx.lineTo(11.000000,304.000000);
  ctx.lineTo(15.000000,320.000000);
  ctx.lineTo(13.000000,334.000000);
  ctx.lineTo(6.000000,348.000000);
  ctx.lineTo(2.000000,353.000000);
  ctx.lineTo(0.000000,363.000000);
  ctx.lineTo(5.000000,372.000000);
  ctx.lineTo(12.000000,374.000000);
  ctx.lineTo(25.000000,372.000000);
  ctx.lineTo(38.000000,372.000000);
  ctx.lineTo(44.000000,369.000000);
  ctx.lineTo(42.000000,367.000000);
  ctx.lineTo(36.000000,368.000000);
  ctx.lineTo(31.000000,369.000000);
  ctx.lineTo(30.000000,360.000000);
  ctx.lineTo(27.000000,368.000000);
  ctx.lineTo(20.000000,370.000000);
  ctx.lineTo(16.000000,361.000000);
  ctx.lineTo(15.000000,368.000000);
  ctx.lineTo(10.000000,369.000000);
  ctx.lineTo(3.000000,366.000000);
  ctx.lineTo(3.000000,359.000000);
  ctx.lineTo(6.000000,352.000000);
  ctx.lineTo(11.000000,348.000000);
  ctx.lineTo(17.000000,331.000000);
  ctx.lineTo(19.000000,316.000000);
  ctx.lineTo(12.000000,291.000000);
  ctx.lineTo(9.000000,274.000000);
  ctx.lineTo(5.000000,255.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(10.000000,358.000000);
  ctx.lineTo(7.000000,362.000000);
  ctx.lineTo(10.000000,366.000000);
  ctx.lineTo(11.000000,362.000000);
  ctx.lineTo(10.000000,358.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(25.000000,357.000000);
  ctx.lineTo(22.000000,360.000000);
  ctx.lineTo(24.000000,366.000000);
  ctx.lineTo(27.000000,360.000000);
  ctx.lineTo(25.000000,357.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(37.000000,357.000000);
  ctx.lineTo(34.000000,361.000000);
  ctx.lineTo(36.000000,365.000000);
  ctx.lineTo(38.000000,361.000000);
  ctx.lineTo(37.000000,357.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(49.000000,356.000000);
  ctx.lineTo(46.000000,359.000000);
  ctx.lineTo(47.000000,364.000000);
  ctx.lineTo(50.000000,360.000000);
  ctx.lineTo(49.000000,356.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(130.000000,101.000000);
  ctx.lineTo(132.000000,102.000000);
  ctx.lineTo(135.000000,101.000000);
  ctx.lineTo(139.000000,102.000000);
  ctx.lineTo(143.000000,103.000000);
  ctx.lineTo(142.000000,101.000000);
  ctx.lineTo(137.000000,100.000000);
  ctx.lineTo(133.000000,100.000000);
  ctx.lineTo(130.000000,101.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(106.000000,48.000000);
  ctx.lineTo(105.000000,52.000000);
  ctx.lineTo(108.000000,56.000000);
  ctx.lineTo(109.000000,52.000000);
  ctx.lineTo(106.000000,48.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(139.000000,52.000000);
  ctx.lineTo(139.000000,56.000000);
  ctx.lineTo(140.000000,60.000000);
  ctx.lineTo(142.000000,58.000000);
  ctx.lineTo(141.000000,56.000000);
  ctx.lineTo(139.000000,52.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(25.000000,349.000000);
  ctx.lineTo(29.000000,351.000000);
  ctx.lineTo(30.000000,355.000000);
  ctx.lineTo(33.000000,350.000000);
  ctx.lineTo(37.000000,348.000000);
  ctx.lineTo(42.000000,351.000000);
  ctx.lineTo(45.000000,347.000000);
  ctx.lineTo(49.000000,345.000000);
  ctx.lineTo(44.000000,343.000000);
  ctx.lineTo(36.000000,345.000000);
  ctx.lineTo(25.000000,349.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(98.000000,347.000000);
  ctx.lineTo(105.000000,351.000000);
  ctx.lineTo(107.000000,354.000000);
  ctx.lineTo(109.000000,349.000000);
  ctx.lineTo(115.000000,349.000000);
  ctx.lineTo(120.000000,353.000000);
  ctx.lineTo(118.000000,349.000000);
  ctx.lineTo(113.000000,346.000000);
  ctx.lineTo(104.000000,346.000000);
  ctx.lineTo(98.000000,347.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(83.000000,348.000000);
  ctx.lineTo(87.000000,352.000000);
  ctx.lineTo(87.000000,357.000000);
  ctx.lineTo(89.000000,351.000000);
  ctx.lineTo(87.000000,348.000000);
  ctx.lineTo(83.000000,348.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(155.000000,107.000000);
  ctx.lineTo(163.000000,107.000000);
  ctx.lineTo(170.000000,107.000000);
  ctx.lineTo(186.000000,108.000000);
  ctx.lineTo(175.000000,109.000000);
  ctx.lineTo(155.000000,109.000000);
  ctx.lineTo(155.000000,107.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(153.000000,114.000000);
  ctx.lineTo(162.000000,113.000000);
  ctx.lineTo(175.000000,112.000000);
  ctx.lineTo(192.000000,114.000000);
  ctx.lineTo(173.000000,114.000000);
  ctx.lineTo(154.000000,115.000000);
  ctx.lineTo(153.000000,114.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(152.000000,118.000000);
  ctx.lineTo(164.000000,120.000000);
  ctx.lineTo(180.000000,123.000000);
  ctx.lineTo(197.000000,129.000000);
  ctx.lineTo(169.000000,123.000000);
  ctx.lineTo(151.000000,120.000000);
  ctx.lineTo(152.000000,118.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(68.000000,109.000000);
  ctx.lineTo(87.000000,106.000000);
  ctx.lineTo(107.000000,106.000000);
  ctx.lineTo(106.000000,108.000000);
  ctx.lineTo(88.000000,108.000000);
  ctx.lineTo(68.000000,109.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(105.000000,111.000000);
  ctx.lineTo(95.000000,112.000000);
  ctx.lineTo(79.000000,114.000000);
  ctx.lineTo(71.000000,116.000000);
  ctx.lineTo(85.000000,115.000000);
  ctx.lineTo(102.000000,113.000000);
  ctx.lineTo(105.000000,111.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(108.000000,101.000000);
  ctx.lineTo(98.000000,99.000000);
  ctx.lineTo(87.000000,99.000000);
  ctx.lineTo(78.000000,99.000000);
  ctx.lineTo(93.000000,100.000000);
  ctx.lineTo(105.000000,102.000000);
  ctx.lineTo(108.000000,101.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(85.000000,63.000000);
  ctx.lineTo(91.000000,63.000000);
  ctx.lineTo(97.000000,60.000000);
  ctx.lineTo(104.000000,60.000000);
  ctx.lineTo(108.000000,62.000000);
  ctx.lineTo(111.000000,69.000000);
  ctx.lineTo(112.000000,75.000000);
  ctx.lineTo(110.000000,74.000000);
  ctx.lineTo(108.000000,71.000000);
  ctx.lineTo(103.000000,73.000000);
  ctx.lineTo(106.000000,69.000000);
  ctx.lineTo(105.000000,65.000000);
  ctx.lineTo(103.000000,64.000000);
  ctx.lineTo(103.000000,67.000000);
  ctx.lineTo(102.000000,70.000000);
  ctx.lineTo(99.000000,70.000000);
  ctx.lineTo(97.000000,66.000000);
  ctx.lineTo(94.000000,67.000000);
  ctx.lineTo(97.000000,72.000000);
  ctx.lineTo(88.000000,67.000000);
  ctx.lineTo(84.000000,66.000000);
  ctx.lineTo(85.000000,63.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(140.000000,74.000000);
  ctx.lineTo(141.000000,66.000000);
  ctx.lineTo(144.000000,61.000000);
  ctx.lineTo(150.000000,61.000000);
  ctx.lineTo(156.000000,62.000000);
  ctx.lineTo(153.000000,70.000000);
  ctx.lineTo(150.000000,73.000000);
  ctx.lineTo(152.000000,65.000000);
  ctx.lineTo(150.000000,65.000000);
  ctx.lineTo(151.000000,68.000000);
  ctx.lineTo(149.000000,71.000000);
  ctx.lineTo(146.000000,71.000000);
  ctx.lineTo(144.000000,66.000000);
  ctx.lineTo(143.000000,70.000000);
  ctx.lineTo(143.000000,74.000000);
  ctx.lineTo(140.000000,74.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(146.000000,20.000000);
  ctx.lineTo(156.000000,11.000000);
  ctx.lineTo(163.000000,9.000000);
  ctx.lineTo(172.000000,9.000000);
  ctx.lineTo(178.000000,14.000000);
  ctx.lineTo(182.000000,18.000000);
  ctx.lineTo(184.000000,32.000000);
  ctx.lineTo(182.000000,42.000000);
  ctx.lineTo(182.000000,52.000000);
  ctx.lineTo(177.000000,58.000000);
  ctx.lineTo(176.000000,67.000000);
  ctx.lineTo(171.000000,76.000000);
  ctx.lineTo(165.000000,90.000000);
  ctx.lineTo(157.000000,105.000000);
  ctx.lineTo(160.000000,92.000000);
  ctx.lineTo(164.000000,85.000000);
  ctx.lineTo(168.000000,78.000000);
  ctx.lineTo(167.000000,73.000000);
  ctx.lineTo(173.000000,66.000000);
  ctx.lineTo(172.000000,62.000000);
  ctx.lineTo(175.000000,59.000000);
  ctx.lineTo(174.000000,55.000000);
  ctx.lineTo(177.000000,53.000000);
  ctx.lineTo(180.000000,46.000000);
  ctx.lineTo(181.000000,29.000000);
  ctx.lineTo(179.000000,21.000000);
  ctx.lineTo(173.000000,13.000000);
  ctx.lineTo(166.000000,11.000000);
  ctx.lineTo(159.000000,13.000000);
  ctx.lineTo(153.000000,18.000000);
  ctx.lineTo(148.000000,23.000000);
  ctx.lineTo(146.000000,20.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(150.000000,187.000000);
  ctx.lineTo(148.000000,211.000000);
  ctx.lineTo(150.000000,233.000000);
  ctx.lineTo(153.000000,247.000000);
  ctx.lineTo(148.000000,267.000000);
  ctx.lineTo(135.000000,283.000000);
  ctx.lineTo(125.000000,299.000000);
  ctx.lineTo(136.000000,292.000000);
  ctx.lineTo(131.000000,313.000000);
  ctx.lineTo(122.000000,328.000000);
  ctx.lineTo(122.000000,345.000000);
  ctx.lineTo(129.000000,352.000000);
  ctx.lineTo(133.000000,359.000000);
  ctx.lineTo(133.000000,367.000000);
  ctx.lineTo(137.000000,359.000000);
  ctx.lineTo(148.000000,356.000000);
  ctx.lineTo(140.000000,350.000000);
  ctx.lineTo(131.000000,347.000000);
  ctx.lineTo(129.000000,340.000000);
  ctx.lineTo(132.000000,332.000000);
  ctx.lineTo(140.000000,328.000000);
  ctx.lineTo(137.000000,322.000000);
  ctx.lineTo(140.000000,304.000000);
  ctx.lineTo(154.000000,265.000000);
  ctx.lineTo(157.000000,244.000000);
  ctx.lineTo(155.000000,223.000000);
  ctx.lineTo(161.000000,220.000000);
  ctx.lineTo(175.000000,229.000000);
  ctx.lineTo(186.000000,247.000000);
  ctx.lineTo(185.000000,260.000000);
  ctx.lineTo(176.000000,275.000000);
  ctx.lineTo(178.000000,287.000000);
  ctx.lineTo(185.000000,277.000000);
  ctx.lineTo(188.000000,261.000000);
  ctx.lineTo(196.000000,253.000000);
  ctx.lineTo(189.000000,236.000000);
  ctx.lineTo(174.000000,213.000000);
  ctx.lineTo(150.000000,187.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(147.000000,338.000000);
  ctx.lineTo(142.000000,341.000000);
  ctx.lineTo(143.000000,345.000000);
  ctx.lineTo(141.000000,354.000000);
  ctx.lineTo(147.000000,343.000000);
  ctx.lineTo(147.000000,338.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(157.000000,342.000000);
  ctx.lineTo(156.000000,349.000000);
  ctx.lineTo(150.000000,356.000000);
  ctx.lineTo(157.000000,353.000000);
  ctx.lineTo(163.000000,346.000000);
  ctx.lineTo(162.000000,342.000000);
  ctx.lineTo(157.000000,342.000000);
ctx.fill();




ctx.fillStyle='#000000';
ctx.beginPath();
ctx.moveTo(99.000000,265.000000);
  ctx.lineTo(96.000000,284.000000);
  ctx.lineTo(92.000000,299.000000);
  ctx.lineTo(73.000000,339.000000);
  ctx.lineTo(73.000000,333.000000);
  ctx.lineTo(87.000000,300.000000);
  ctx.lineTo(99.000000,265.000000);
ctx.fill();



}